package com.myfire.launcher

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.DownloadManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import kotlin.math.abs
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.view.KeyEvent
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import kotlin.math.ceil
import kotlin.math.exp
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject

data class AppItem(val pkg: String, val label: String, val white: Bitmap?, val color: Bitmap?, val banner: Bitmap?)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden", v.toSet()).apply() }
    var order: List<String>
        get() = (sp.getString("order", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("order", v.joinToString(",")).apply() }
    var tileSize: Int
        get() = sp.getInt("tile", 1)
        set(v) { sp.edit().putInt("tile", v).apply() }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var favs: Set<String>
        get() = sp.getStringSet("favs", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("favs", v.toSet()).apply() }
    var artModes: Map<String, Int>
        get() = (sp.getStringSet("art", emptySet()) ?: emptySet()).mapNotNull {
            val i = it.lastIndexOf('=')
            if (i < 0) null else it.substring(0, i) to (it.substring(i + 1).toIntOrNull() ?: 0)
        }.toMap()
        set(v) { sp.edit().putStringSet("art", v.map { "${it.key}=${it.value}" }.toSet()).apply() }
    var seeded: Boolean
        get() = sp.getBoolean("seeded", false)
        set(v) { sp.edit().putBoolean("seeded", v).apply() }
    var sleepAt: Long
        get() = sp.getLong("sleepAt", 0L)
        set(v) { sp.edit().putLong("sleepAt", v).apply() }
    var look: Look
        get() = Look(sp.getInt("l_accent", 0), sp.getInt("l_ring", 1), sp.getInt("l_shape", 1),
            sp.getInt("l_font", 0), sp.getInt("l_dark", 4), sp.getInt("l_blur", 0), sp.getInt("l_logo", 0))
        set(v) {
            sp.edit().putInt("l_accent", v.accent).putInt("l_ring", v.ring).putInt("l_shape", v.shape)
                .putInt("l_font", v.font).putInt("l_dark", v.dark).putInt("l_blur", v.blur).putInt("l_logo", v.logo).apply()
        }
    var wx: Wx
        get() = Wx(sp.getString("w_city", "") ?: "",
            (sp.getString("w_lat", "0") ?: "0").toDoubleOrNull() ?: 0.0,
            (sp.getString("w_lon", "0") ?: "0").toDoubleOrNull() ?: 0.0,
            sp.getBoolean("w_f", false), sp.getBoolean("w_on", false))
        set(v) {
            sp.edit().putString("w_city", v.city).putString("w_lat", v.lat.toString())
                .putString("w_lon", v.lon.toString()).putBoolean("w_f", v.f).putBoolean("w_on", v.on).apply()
        }
}

data class Look(
    val accent: Int = 0, val ring: Int = 1, val shape: Int = 1,
    val font: Int = 0, val dark: Int = 4, val blur: Int = 0, val logo: Int = 0
)

data class Wx(
    val city: String = "", val lat: Double = 0.0, val lon: Double = 0.0,
    val f: Boolean = false, val on: Boolean = false
)

private const val ART = 192
private val artCache = HashMap<String, AppItem>()

private fun renderTo(d: Drawable, w: Int, h: Int): Bitmap {
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, w, h)
    d.draw(Canvas(bmp))
    return bmp
}

private fun coverage(b: Bitmap): Float {
    val px = IntArray(b.width * b.height)
    b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
    var n = 0
    for (p in px) if ((p ushr 24) > 200) n++
    return n.toFloat() / px.size
}

private fun trimToContent(src: Bitmap): Bitmap? {
    val w = src.width
    val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    var minX = w
    var minY = h
    var maxX = -1
    var maxY = -1
    for (y in 0 until h) for (x in 0 until w) {
        if ((px[y * w + x] ushr 24) > 20) {
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
        }
    }
    if (maxX < 0) return null
    val cw = maxX - minX + 1
    val ch = maxY - minY + 1
    val crop = Bitmap.createBitmap(src, minX, minY, cw, ch)
    val s = ART.toFloat() / maxOf(cw, ch)
    return Bitmap.createScaledBitmap(crop, maxOf(1, (cw * s).toInt()), maxOf(1, (ch * s).toInt()), true)
}

private fun toWhite(src: Bitmap): Bitmap {
    val w = src.width
    val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    for (i in px.indices) px[i] = ((px[i] ushr 24) shl 24) or 0xFFFFFF
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(px, 0, w, 0, 0, w, h)
    return out
}

// For opaque icons: keep only what differs from the background color, as a white shape.
private fun glyphFromOpaque(b: Bitmap): Bitmap? {
    val w = b.width
    val h = b.height
    val px = IntArray(w * h)
    b.getPixels(px, 0, w, 0, 0, w, h)
    val m = maxOf(2, (w * 0.06f).toInt())
    var sr = 0L
    var sg = 0L
    var sb = 0L
    var n = 0
    for (y in 0 until h) for (x in 0 until w) {
        if (x < m || y < m || x >= w - m || y >= h - m) {
            val p = px[y * w + x]
            if ((p ushr 24) > 200) {
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
                n++
            }
        }
    }
    if (n < 10) return null
    val br = (sr / n).toInt()
    val bg = (sg / n).toInt()
    val bb = (sb / n).toInt()
    var on = 0
    for (i in px.indices) {
        val p = px[i]
        val a0 = p ushr 24
        val d = maxOf(abs(((p shr 16) and 255) - br), abs(((p shr 8) and 255) - bg), abs((p and 255) - bb))
        val a = (((d - 40) * 255) / 80).coerceIn(0, 255)
        val a2 = minOf(a, a0)
        if (a2 > 128) on++
        px[i] = (a2 shl 24) or 0xFFFFFF
    }
    val frac = on.toFloat() / px.size
    if (frac < 0.02f || frac > 0.6f) return null
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(px, 0, w, 0, 0, w, h)
    return trimToContent(out)
}

private fun buildItem(pm: PackageManager, ri: ResolveInfo, pkg: String): AppItem {
    val label = ri.loadLabel(pm).toString()
    val icon = ri.loadIcon(pm)
    val bannerD = ri.activityInfo.loadBanner(pm)
    val banner = if (bannerD != null) renderTo(bannerD, 320, 180) else null
    var white: Bitmap? = null
    var color: Bitmap? = null
    var layer: Bitmap? = null
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && icon is AdaptiveIconDrawable) {
        val fg = icon.foreground
        if (fg != null) {
            val b = renderTo(fg, 216, 216)
            if (coverage(b) < 0.85f) layer = b
        }
    }
    if (layer != null) {
        val t = trimToContent(layer)
        if (t != null) {
            color = t
            white = toWhite(t)
        }
    }
    if (white == null) {
        val full = renderTo(icon, 216, 216)
        color = Bitmap.createScaledBitmap(full, ART, ART, true)
        white = glyphFromOpaque(full)
    }
    return AppItem(pkg, label, white, color, banner)
}

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val seen = HashSet<String>()
    val out = ArrayList<AppItem>()
    for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val upd = try { pm.getPackageInfo(pkg, 0).lastUpdateTime } catch (e: Exception) { 0L }
            val key = "$pkg:$upd"
            val cached = artCache[key]
            if (cached != null) {
                out.add(cached)
                continue
            }
            try {
                val item = buildItem(pm, ri, pkg)
                artCache[key] = item
                out.add(item)
            } catch (e: Exception) { }
        }
    }
    return out
}

fun sortApps(all: List<AppItem>, order: List<String>): List<AppItem> {
    val idx = order.withIndex().associate { it.value to it.index }
    return all.sortedWith(compareBy<AppItem>({ idx[it.pkg] ?: Int.MAX_VALUE }, { it.label.lowercase() }))
}

fun launchApp(ctx: Context, pkg: String) {
    val pm = ctx.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
    if (i != null) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

fun apkFile(ctx: Context): File =
    File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "update.apk")

fun enqueueDownload(ctx: Context, url: String): Long {
    val f = apkFile(ctx)
    if (f.exists()) f.delete()
    val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val req = DownloadManager.Request(Uri.parse(url))
        .setTitle("Downloading app")
        .setMimeType("application/vnd.android.package-archive")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
        .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, "update.apk")
    return dm.enqueue(req)
}

fun installApk(ctx: Context, file: File) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
    val i = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, "application/vnd.android.package-archive")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(i)
}

fun wallpaperFile(ctx: Context): File = File(ctx.filesDir, "wallpaper.jpg")

fun downloadWallpaper(ctx: Context, url: String): Boolean {
    return try {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        val bytes = conn.inputStream.use { it.readBytes() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1920) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false
        val out = if (bmp.width > 1280) Bitmap.createScaledBitmap(bmp, 1280, bmp.height * 1280 / bmp.width, true) else bmp
        wallpaperFile(ctx).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Exception) {
        false
    }
}

fun loadWallpaper(ctx: Context): Bitmap? {
    val f = wallpaperFile(ctx)
    return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
}

val SIGMAS = listOf(0f, 2f, 4f, 7f, 10f, 14f)

fun gaussianBlur(src: Bitmap, level: Int): Bitmap {
    val sigma = SIGMAS[level.coerceIn(0, SIGMAS.size - 1)]
    if (sigma <= 0f) return src
    val w = 480
    val h = maxOf(1, src.height * w / maxOf(1, src.width))
    val small = Bitmap.createScaledBitmap(src, w, h, true)
    val px = IntArray(w * h)
    small.getPixels(px, 0, w, 0, 0, w, h)
    val r = ceil(sigma * 3f).toInt()
    val k = FloatArray(2 * r + 1)
    var sum = 0f
    for (i in -r..r) {
        val v = exp(-(i * i) / (2f * sigma * sigma))
        k[i + r] = v
        sum += v
    }
    for (i in k.indices) k[i] /= sum
    val tmp = IntArray(w * h)
    blurPass(px, tmp, w, h, k, r, true)
    blurPass(tmp, px, w, h, k, r, false)
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(px, 0, w, 0, 0, w, h)
    return out
}

private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, k: FloatArray, r: Int, horiz: Boolean) {
    for (y in 0 until h) {
        for (x in 0 until w) {
            var rr = 0f
            var g = 0f
            var b = 0f
            for (i in -r..r) {
                val xx = if (horiz) (x + i).coerceIn(0, w - 1) else x
                val yy = if (horiz) y else (y + i).coerceIn(0, h - 1)
                val p = src[yy * w + xx]
                val wt = k[i + r]
                rr += ((p shr 16) and 255) * wt
                g += ((p shr 8) and 255) * wt
                b += (p and 255) * wt
            }
            dst[y * w + x] = (255 shl 24) or
                (rr.toInt().coerceIn(0, 255) shl 16) or
                (g.toInt().coerceIn(0, 255) shl 8) or
                b.toInt().coerceIn(0, 255)
        }
    }
}

private fun httpGet(u: String): String {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 15000
    return c.inputStream.bufferedReader().use { it.readText() }
}

fun geocode(city: String): Wx? {
    return try {
        val q = URLEncoder.encode(city, "UTF-8")
        val arr = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1")).optJSONArray("results")
        val o = arr?.getJSONObject(0)
        if (o == null) null else Wx(o.getString("name"), o.getDouble("latitude"), o.getDouble("longitude"), false, true)
    } catch (e: Exception) {
        null
    }
}

private fun wxName(code: Int): String = when (code) {
    0 -> "Clear"
    1, 2 -> "Partly cloudy"
    3 -> "Cloudy"
    45, 48 -> "Fog"
    in 51..57 -> "Drizzle"
    in 61..67, in 80..82 -> "Rain"
    in 71..77, 85, 86 -> "Snow"
    in 95..99 -> "Thunderstorm"
    else -> ""
}

fun fetchWeather(w: Wx): String? {
    return try {
        val unit = if (w.f) "fahrenheit" else "celsius"
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${w.lat}&longitude=${w.lon}" +
            "&current=temperature_2m,weather_code&temperature_unit=$unit"
        val cur = JSONObject(httpGet(url)).getJSONObject("current")
        val t = Math.round(cur.getDouble("temperature_2m"))
        val u = if (w.f) "F" else "C"
        "$t\u00B0$u " + wxName(cur.getInt("weather_code")) + " - " + w.city
    } catch (e: Exception) {
        null
    }
}

class SleepReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE))
        ctx.startActivity(
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("sleep", true)
        )
    }
}

private fun sleepIntent(ctx: Context): PendingIntent =
    PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, SleepReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

fun setSleepTimer(ctx: Context, minutes: Int): Long {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val at = System.currentTimeMillis() + minutes * 60_000L
    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, sleepIntent(ctx))
    return at
}

fun cancelSleepTimer(ctx: Context) {
    (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(sleepIntent(ctx))
}

fun freeMb(ctx: Context): Long {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    return mi.availMem / 1048576L
}

fun killOthers(ctx: Context, pkgs: List<String>) {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    for (p in pkgs) if (p != ctx.packageName) am.killBackgroundProcesses(p)
}
