package com.myfire.launcher

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.DownloadManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import androidx.core.graphics.PathParser
import java.io.FileNotFoundException
import java.io.IOException
import android.graphics.drawable.AdaptiveIconDrawable
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import kotlin.math.abs
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.view.KeyEvent
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import kotlin.math.ceil
import kotlin.random.Random
import kotlin.math.exp
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject

data class AppItem(val pkg: String, val label: String, val white: Bitmap?, val color: Bitmap?, val banner: Bitmap?)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden", v.toSet()).apply() }
    var order: List<String>
        get() = (sp.getString("order", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("order", v.joinToString(",")).apply() }
    var tileSize: Int
        get() = sp.getInt("tile", 1)
        set(v) { sp.edit().putInt("tile", v).apply() }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var favs: Set<String>
        get() = sp.getStringSet("favs", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("favs", v.toSet()).apply() }
    var artModes: Map<String, Int>
        get() = (sp.getStringSet("art", emptySet()) ?: emptySet()).mapNotNull {
            val i = it.lastIndexOf('=')
            if (i < 0) null else it.substring(0, i) to (it.substring(i + 1).toIntOrNull() ?: 0)
        }.toMap()
        set(v) { sp.edit().putStringSet("art", v.map { "${it.key}=${it.value}" }.toSet()).apply() }
    var triedLogos: Set<String>
        get() = sp.getStringSet("tried2", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("tried2", v.toSet()).apply() }
    var region: Int
        get() = sp.getInt("region", 0)
        set(v) { sp.edit().putInt("region", v).apply() }
    var traktId: String
        get() = sp.getString("traktId", "") ?: ""
        set(v) { sp.edit().putString("traktId", v.trim()).apply() }
    var traktSecret: String
        get() = sp.getString("traktSecret", "") ?: ""
        set(v) { sp.edit().putString("traktSecret", v.trim()).apply() }
    var traktAccess: String
        get() = sp.getString("traktAccess", "") ?: ""
        set(v) { sp.edit().putString("traktAccess", v).apply() }
    var traktRefresh: String
        get() = sp.getString("traktRefresh", "") ?: ""
        set(v) { sp.edit().putString("traktRefresh", v).apply() }
    var traktExpires: Long
        get() = sp.getLong("traktExpires", 0L)
        set(v) { sp.edit().putLong("traktExpires", v).apply() }
    var traktUser: String
        get() = sp.getString("traktUser", "") ?: ""
        set(v) { sp.edit().putString("traktUser", v.trim()).apply() }
    var ambient: Boolean
        get() = sp.getBoolean("ambient", true)
        set(v) { sp.edit().putBoolean("ambient", v).apply() }
    var cinematic: Boolean
        get() = sp.getBoolean("cinematic", true)
        set(v) { sp.edit().putBoolean("cinematic", v).apply() }
    var heroPkg: String
        get() = sp.getString("heroPkg", "") ?: ""
        set(v) { sp.edit().putString("heroPkg", v).apply() }
    var heroTypes: Int
        get() = sp.getInt("heroTypes", 0)
        set(v) { sp.edit().putInt("heroTypes", v).apply() }
    var heroGenres: Set<String>
        get() = sp.getStringSet("heroGenres", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("heroGenres", v.toSet()).apply() }
    var taste: Map<String, Int>
        get() = (sp.getStringSet("taste", emptySet()) ?: emptySet()).mapNotNull {
            val i = it.lastIndexOf('=')
            if (i < 0) null else it.substring(0, i) to (it.substring(i + 1).toIntOrNull() ?: 0)
        }.toMap()
        set(v) { sp.edit().putStringSet("taste", v.map { "${it.key}=${it.value}" }.toSet()).apply() }
    var seeded: Boolean
        get() = sp.getBoolean("seeded", false)
        set(v) { sp.edit().putBoolean("seeded", v).apply() }
    var sleepAt: Long
        get() = sp.getLong("sleepAt", 0L)
        set(v) { sp.edit().putLong("sleepAt", v).apply() }
    var look: Look
        get() = Look(sp.getInt("l_accent", 0), sp.getInt("l_ring2", 5), sp.getInt("l_shape", 1),
            sp.getInt("l_font2", 0), sp.getInt("l_dark", 4), sp.getInt("l_blur", 0), sp.getInt("l_logo", 0))
        set(v) {
            sp.edit().putInt("l_accent", v.accent).putInt("l_ring2", v.ring).putInt("l_shape", v.shape)
                .putInt("l_font2", v.font).putInt("l_dark", v.dark).putInt("l_blur", v.blur).putInt("l_logo", v.logo).apply()
        }
    var wx: Wx
        get() = Wx(sp.getString("w_city", "") ?: "",
            (sp.getString("w_lat", "0") ?: "0").toDoubleOrNull() ?: 0.0,
            (sp.getString("w_lon", "0") ?: "0").toDoubleOrNull() ?: 0.0,
            sp.getBoolean("w_f", false), sp.getBoolean("w_on", false))
        set(v) {
            sp.edit().putString("w_city", v.city).putString("w_lat", v.lat.toString())
                .putString("w_lon", v.lon.toString()).putBoolean("w_f", v.f).putBoolean("w_on", v.on).apply()
        }
}

data class Look(
    val accent: Int = 0, val ring: Int = 5, val shape: Int = 1,
    val font: Int = 0, val dark: Int = 4, val blur: Int = 0, val logo: Int = 0
)

data class Wx(
    val city: String = "", val lat: Double = 0.0, val lon: Double = 0.0,
    val f: Boolean = false, val on: Boolean = false
)

private const val ART = 192
private val artCache = HashMap<String, AppItem>()

private fun renderTo(d: Drawable, w: Int, h: Int): Bitmap {
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, w, h)
    d.draw(Canvas(bmp))
    return bmp
}

private fun coverage(b: Bitmap): Float {
    val px = IntArray(b.width * b.height)
    b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
    var n = 0
    for (p in px) if ((p ushr 24) > 200) n++
    return n.toFloat() / px.size
}

private fun trimToContent(src: Bitmap): Bitmap? {
    val w = src.width
    val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    var minX = w
    var minY = h
    var maxX = -1
    var maxY = -1
    for (y in 0 until h) for (x in 0 until w) {
        if ((px[y * w + x] ushr 24) > 20) {
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
        }
    }
    if (maxX < 0) return null
    val cw = maxX - minX + 1
    val ch = maxY - minY + 1
    val crop = Bitmap.createBitmap(src, minX, minY, cw, ch)
    val s = ART.toFloat() / maxOf(cw, ch)
    return Bitmap.createScaledBitmap(crop, maxOf(1, (cw * s).toInt()), maxOf(1, (ch * s).toInt()), true)
}

private fun toWhite(src: Bitmap): Bitmap {
    val w = src.width
    val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    for (i in px.indices) px[i] = ((px[i] ushr 24) shl 24) or 0xFFFFFF
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(px, 0, w, 0, 0, w, h)
    return out
}

// For opaque icons: keep only what differs from the background color, as a white shape.
private fun glyphFromOpaque(b: Bitmap): Bitmap? {
    val w = b.width
    val h = b.height
    val px = IntArray(w * h)
    b.getPixels(px, 0, w, 0, 0, w, h)
    val m = maxOf(2, (w * 0.06f).toInt())
    var sr = 0L
    var sg = 0L
    var sb = 0L
    var n = 0
    for (y in 0 until h) for (x in 0 until w) {
        if (x < m || y < m || x >= w - m || y >= h - m) {
            val p = px[y * w + x]
            if ((p ushr 24) > 200) {
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
                n++
            }
        }
    }
    if (n < 10) return null
    val br = (sr / n).toInt()
    val bg = (sg / n).toInt()
    val bb = (sb / n).toInt()
    var on = 0
    for (i in px.indices) {
        val p = px[i]
        val a0 = p ushr 24
        val d = maxOf(abs(((p shr 16) and 255) - br), abs(((p shr 8) and 255) - bg), abs((p and 255) - bb))
        val a = (((d - 40) * 255) / 80).coerceIn(0, 255)
        val a2 = minOf(a, a0)
        if (a2 > 128) on++
        px[i] = (a2 shl 24) or 0xFFFFFF
    }
    val frac = on.toFloat() / px.size
    if (frac < 0.02f || frac > 0.6f) return null
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(px, 0, w, 0, 0, w, h)
    return trimToContent(out)
}

private fun buildItem(pm: PackageManager, ri: ResolveInfo, pkg: String): AppItem {
    val label = ri.loadLabel(pm).toString()
    val icon = ri.loadIcon(pm)
    val bannerD = ri.activityInfo.loadBanner(pm)
    val banner = if (bannerD != null) renderTo(bannerD, 320, 180) else null
    var white: Bitmap? = null
    var color: Bitmap? = null
    var layer: Bitmap? = null
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && icon is AdaptiveIconDrawable) {
        val fg = icon.foreground
        if (fg != null) {
            val b = renderTo(fg, 216, 216)
            if (coverage(b) < 0.85f) layer = b
        }
    }
    if (layer != null) {
        val t = trimToContent(layer)
        if (t != null) {
            color = t
            white = toWhite(t)
        }
    }
    if (white == null) {
        val full = renderTo(icon, 216, 216)
        color = Bitmap.createScaledBitmap(full, ART, ART, true)
        white = glyphFromOpaque(full)
    }
    return AppItem(pkg, label, white, color, banner)
}

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val seen = HashSet<String>()
    val out = ArrayList<AppItem>()
    for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val upd = try { pm.getPackageInfo(pkg, 0).lastUpdateTime } catch (e: Exception) { 0L }
            val key = "$pkg:$upd"
            val cached = artCache[key]
            if (cached != null) {
                out.add(cached)
                continue
            }
            try {
                val item = buildItem(pm, ri, pkg)
                artCache[key] = item
                out.add(item)
            } catch (e: Exception) { }
        }
    }
    return out
}

fun sortApps(all: List<AppItem>, order: List<String>): List<AppItem> {
    val idx = order.withIndex().associate { it.value to it.index }
    return all.sortedWith(compareBy<AppItem>({ idx[it.pkg] ?: Int.MAX_VALUE }, { it.label.lowercase() }))
}

fun launchApp(ctx: Context, pkg: String) {
    val pm = ctx.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
    if (i != null) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

fun apkFile(ctx: Context): File =
    File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "update.apk")

fun enqueueDownload(ctx: Context, url: String): Long {
    val f = apkFile(ctx)
    if (f.exists()) f.delete()
    val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val req = DownloadManager.Request(Uri.parse(url))
        .setTitle("Downloading app")
        .setMimeType("application/vnd.android.package-archive")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
        .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, "update.apk")
    return dm.enqueue(req)
}

fun installApk(ctx: Context, file: File) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
    val i = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, "application/vnd.android.package-archive")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(i)
}

fun wallpaperFile(ctx: Context): File = File(ctx.filesDir, "wallpaper.jpg")

fun downloadWallpaper(ctx: Context, url: String): Boolean {
    return try {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        val bytes = conn.inputStream.use { it.readBytes() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1920) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false
        val out = if (bmp.width > 1280) Bitmap.createScaledBitmap(bmp, 1280, bmp.height * 1280 / bmp.width, true) else bmp
        wallpaperFile(ctx).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Exception) {
        false
    }
}

fun loadWallpaper(ctx: Context): Bitmap? {
    val f = wallpaperFile(ctx)
    return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
}

val SIGMAS = listOf(0f, 2f, 4f, 7f, 10f, 14f)

fun gaussianBlur(src: Bitmap, level: Int): Bitmap {
    val sigma = SIGMAS[level.coerceIn(0, SIGMAS.size - 1)]
    if (sigma <= 0f) return src
    val w = 480
    val h = maxOf(1, src.height * w / maxOf(1, src.width))
    val small = Bitmap.createScaledBitmap(src, w, h, true)
    val px = IntArray(w * h)
    small.getPixels(px, 0, w, 0, 0, w, h)
    val r = ceil(sigma * 3f).toInt()
    val k = FloatArray(2 * r + 1)
    var sum = 0f
    for (i in -r..r) {
        val v = exp(-(i * i) / (2f * sigma * sigma))
        k[i + r] = v
        sum += v
    }
    for (i in k.indices) k[i] /= sum
    val tmp = IntArray(w * h)
    blurPass(px, tmp, w, h, k, r, true)
    blurPass(tmp, px, w, h, k, r, false)
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(px, 0, w, 0, 0, w, h)
    return out
}

private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, k: FloatArray, r: Int, horiz: Boolean) {
    for (y in 0 until h) {
        for (x in 0 until w) {
            var rr = 0f
            var g = 0f
            var b = 0f
            for (i in -r..r) {
                val xx = if (horiz) (x + i).coerceIn(0, w - 1) else x
                val yy = if (horiz) y else (y + i).coerceIn(0, h - 1)
                val p = src[yy * w + xx]
                val wt = k[i + r]
                rr += ((p shr 16) and 255) * wt
                g += ((p shr 8) and 255) * wt
                b += (p and 255) * wt
            }
            dst[y * w + x] = (255 shl 24) or
                (rr.toInt().coerceIn(0, 255) shl 16) or
                (g.toInt().coerceIn(0, 255) shl 8) or
                b.toInt().coerceIn(0, 255)
        }
    }
}

private fun httpGet(u: String): String {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 15000
    return c.inputStream.bufferedReader().use { it.readText() }
}

fun geocode(city: String): Wx? {
    return try {
        val q = URLEncoder.encode(city, "UTF-8")
        val arr = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1")).optJSONArray("results")
        val o = arr?.getJSONObject(0)
        if (o == null) null else Wx(o.getString("name"), o.getDouble("latitude"), o.getDouble("longitude"), false, true)
    } catch (e: Exception) {
        null
    }
}

private fun wxName(code: Int): String = when (code) {
    0 -> "Clear"
    1, 2 -> "Partly cloudy"
    3 -> "Cloudy"
    45, 48 -> "Fog"
    in 51..57 -> "Drizzle"
    in 61..67, in 80..82 -> "Rain"
    in 71..77, 85, 86 -> "Snow"
    in 95..99 -> "Thunderstorm"
    else -> ""
}

fun fetchWeather(w: Wx): String? {
    return try {
        val unit = if (w.f) "fahrenheit" else "celsius"
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${w.lat}&longitude=${w.lon}" +
            "&current=temperature_2m,weather_code&temperature_unit=$unit"
        val cur = JSONObject(httpGet(url)).getJSONObject("current")
        val t = Math.round(cur.getDouble("temperature_2m"))
        val u = if (w.f) "F" else "C"
        "$t\u00B0$u " + wxName(cur.getInt("weather_code")) + " - " + w.city
    } catch (e: Exception) {
        null
    }
}

class SleepReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE))
        ctx.startActivity(
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("sleep", true)
        )
    }
}

private fun sleepIntent(ctx: Context): PendingIntent =
    PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, SleepReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

fun setSleepTimer(ctx: Context, minutes: Int): Long {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val at = System.currentTimeMillis() + minutes * 60_000L
    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, sleepIntent(ctx))
    return at
}

fun cancelSleepTimer(ctx: Context) {
    (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(sleepIntent(ctx))
}

fun freeMb(ctx: Context): Long {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    return mi.availMem / 1048576L
}

fun killOthers(ctx: Context, pkgs: List<String>) {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    for (p in pkgs) if (p != ctx.packageName) am.killBackgroundProcesses(p)
}

// ---------- online minimal logos (Simple Icons) ----------

private val GENERIC = setOf(
    "home", "news", "settings", "downloads", "browser", "photos", "music", "video", "videos", "tv",
    "store", "apps", "appstore", "files", "clock", "calendar", "camera", "weather", "screensaver",
    "game", "games", "kids", "live", "search", "help", "profile", "troubleshooting"
)
private val DROP = setOf("tv", "app", "hd", "the", "for", "android", "fire", "official", "mobile", "lite")
private val PKG_SKIP = setOf(
    "com", "org", "net", "io", "android", "app", "apps", "tv", "amazon", "google", "firetv", "ninja",
    "livingroom", "atve", "mobile", "client", "launcher", "main", "player", "tvapp", "androidtv", "leanback"
)
private val FIRST_SKIP = setOf("amazon", "google", "apple", "microsoft", "samsung", "system", "android", "fire")

fun slugCandidates(label: String, pkg: String, strict: Boolean = true): List<String> {
    val base = label.lowercase().replace("+", "plus").replace("&", "and")
    val full = base.replace(Regex("[^a-z0-9]"), "")
    if (strict && full in GENERIC) return emptyList()
    val out = LinkedHashSet<String>()
    if (full.isNotEmpty()) out.add(full)
    val words = base.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
    val kept = words.filter { it !in DROP }
    if (kept.isNotEmpty()) out.add(kept.joinToString(""))
    for (seg in pkg.lowercase().split('.')) {
        val s = seg.replace(Regex("[^a-z0-9]"), "")
        if (s.length >= 4 && s !in PKG_SKIP) out.add(s)
    }
    val first = kept.firstOrNull()
    if (strict && first != null && kept.size > 1 && first.length >= 4 && first !in FIRST_SKIP) out.add(first)
    return out.filter { it.isNotEmpty() }.take(6)
}

private fun svgToWhite(svg: String): Bitmap? {
    return try {
        val paths = Regex("<path[^>]*?\\sd=\"([^\"]+)\"").findAll(svg).map { it.groupValues[1] }.toList()
        if (paths.isEmpty()) return null
        var vx = 0f
        var vy = 0f
        var vw = 24f
        var vh = 24f
        val vb = Regex("viewBox=\"([^\"]+)\"").find(svg)
        if (vb != null) {
            val n = vb.groupValues[1].trim().split(Regex("[\\s,]+")).mapNotNull { it.toFloatOrNull() }
            if (n.size == 4 && n[2] > 0f && n[3] > 0f) {
                vx = n[0]; vy = n[1]; vw = n[2]; vh = n[3]
            }
        }
        val size = 240
        val s = size / maxOf(vw, vh)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate((size - vw * s) / 2f, (size - vh * s) / 2f)
        c.scale(s, s)
        c.translate(-vx, -vy)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = android.graphics.Color.WHITE
        paint.style = Paint.Style.FILL
        for (dd in paths) c.drawPath(PathParser.createPathFromPathData(dd), paint)
        trimToContent(bmp)
    } catch (e: Exception) {
        null
    }
}

fun logoFile(ctx: Context, pkg: String): File {
    val dir = File(ctx.filesDir, "logos")
    dir.mkdirs()
    return File(dir, "$pkg.png")
}

private fun saveLogo(ctx: Context, pkg: String, bmp: Bitmap?): Bitmap? {
    if (bmp == null) return null
    logoFile(ctx, pkg).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return bmp
}

private val MIRRORS = listOf(
    "https://cdn.jsdelivr.net/npm/simple-icons@latest/icons/%s.svg",
    "https://unpkg.com/simple-icons@latest/icons/%s.svg",
    "https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/%s.svg",
    "https://api.iconify.design/simple-icons/%s.svg"
)

// null = this brand does not exist; throws IOException only if every mirror is unreachable.
private fun fetchSimpleIcon(slug: String): String? {
    var last: IOException? = null
    for (m in MIRRORS) {
        try {
            return httpGet(m.format(slug))
        } catch (e: FileNotFoundException) {
            return null
        } catch (e: IOException) {
            last = e
        }
    }
    throw last ?: IOException("no mirror reachable")
}

private fun iconifySvg(id: String): String? {
    return try {
        httpGet("https://api.iconify.design/" + id.substringBefore(':') + "/" + id.substringAfter(':') + ".svg")
    } catch (e: FileNotFoundException) {
        null
    }
}

private fun iconifySearch(query: String, exact: Boolean): List<String> {
    val q = URLEncoder.encode(query, "UTF-8")
    val arr = JSONObject(httpGet("https://api.iconify.design/search?query=$q&limit=32&prefixes=simple-icons,logos,mdi"))
        .optJSONArray("icons") ?: return emptyList()
    val key = query.lowercase().replace(Regex("[^a-z0-9]"), "")
    val ids = (0 until arr.length()).map { arr.getString(it) }
    val ok = ids.filter {
        val n = it.substringAfter(':').replace("-", "")
        n == key || (!exact && key.length >= 5 && n.startsWith(key))
    }
    return ok.sortedBy { if (it.startsWith("simple-icons:")) 0 else if (it.startsWith("logos:")) 1 else 2 }
}

private fun logoFromUrl(url: String): Bitmap? {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 20000
    c.instanceFollowRedirects = true
    c.setRequestProperty("User-Agent", "Mozilla/5.0 FireLauncher")
    val bytes = c.inputStream.use { it.readBytes() }
    val head = String(bytes, 0, minOf(bytes.size, 400)).lowercase()
    if (head.contains("<svg") || head.contains("<?xml")) return svgToWhite(String(bytes))
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (bounds.outWidth / sample > 600) sample *= 2
    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        ?: return null
    val s = 256f / maxOf(raw.width, raw.height)
    val scaled = Bitmap.createScaledBitmap(raw, maxOf(1, (raw.width * s).toInt()), maxOf(1, (raw.height * s).toInt()), true)
    return if (coverage(scaled) < 0.85f) {
        trimToContent(scaled)?.let { toWhite(it) }
    } else {
        glyphFromOpaque(scaled)
    }
}

// Finds a minimal white logo and saves it. Throws IOException if offline.
fun findLogo(ctx: Context, pkg: String, name: String, pkgName: String, strict: Boolean): Bitmap? {
    val t = name.trim()
    if (t.isEmpty()) return null
    if (t.startsWith("http", ignoreCase = true)) return saveLogo(ctx, pkg, logoFromUrl(t))
    if (t.contains(':') && !t.contains(' ')) {
        val svg = iconifySvg(t) ?: return null
        return saveLogo(ctx, pkg, svgToWhite(svg))
    }
    val cands = slugCandidates(t, pkgName, strict)
    if (strict && cands.isEmpty()) return null
    for (s in cands) {
        val svg = fetchSimpleIcon(s) ?: continue
        val bmp = svgToWhite(svg) ?: continue
        return saveLogo(ctx, pkg, bmp)
    }
    try {
        val words = t.lowercase().replace("+", " plus").split(Regex("[^a-z0-9]+"))
            .filter { it.isNotEmpty() && it !in DROP }
        if (words.isNotEmpty()) {
            for (id in iconifySearch(words.joinToString(" "), false)) {
                val svg = iconifySvg(id) ?: continue
                val bmp = svgToWhite(svg) ?: continue
                return saveLogo(ctx, pkg, bmp)
            }
            if (words.size > 1 && words[0].length >= 4 && (!strict || words[0] !in FIRST_SKIP)) {
                for (id in iconifySearch(words[0], true)) {
                    val svg = iconifySvg(id) ?: continue
                    val bmp = svgToWhite(svg) ?: continue
                    return saveLogo(ctx, pkg, bmp)
                }
            }
        }
    } catch (e: IOException) {
    }
    return null
}

fun loadOnlineLogos(ctx: Context): Map<String, Bitmap> {
    val out = HashMap<String, Bitmap>()
    File(ctx.filesDir, "logos").listFiles()?.forEach { f ->
        if (f.name.endsWith(".png")) {
            BitmapFactory.decodeFile(f.path)?.let { out[f.name.removeSuffix(".png")] = it }
        }
    }
    return out
}

fun deleteOnlineLogo(ctx: Context, pkg: String) {
    logoFile(ctx, pkg).delete()
}

// ---------- recommendations (Cinemeta: the catalog Nuvio uses, no key needed) ----------

data class Hero(
    val id: String, val type: String, val name: String, val year: String,
    val rating: String, val genres: List<String>, val overview: String, val bg: String,
    val tag: String = "", val logo: String = "", val indian: Boolean = false
)

data class HeroCache(val key: String, val time: Long, val items: List<Hero>)

val ALL_GENRES = listOf(
    "Action", "Adventure", "Animation", "Comedy", "Crime", "Documentary", "Drama",
    "Family", "Fantasy", "Horror", "Mystery", "Romance", "Sci-Fi", "Thriller"
)

private const val CINEMETA = "https://v3-cinemeta.strem.io"

fun learnTaste(m: Map<String, Int>, genres: List<String>): Map<String, Int> {
    val out = m.toMutableMap()
    for (g in genres) out[g] = (out[g] ?: 0) + 1
    return out
}

fun topTaste(m: Map<String, Int>): List<String> =
    m.entries.sortedByDescending { it.value }.take(2).map { it.key }

private fun catalogIds(type: String, genre: String?, limit: Int): List<String> {
    return try {
        val path = if (genre == null) "top" else "top/genre=" + URLEncoder.encode(genre, "UTF-8")
        val arr = JSONObject(httpGet("$CINEMETA/catalog/$type/$path.json")).optJSONArray("metas")
            ?: return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until minOf(arr.length(), limit)) {
            val id = arr.getJSONObject(i).optString("id")
            if (id.startsWith("tt")) out.add(id)
        }
        out
    } catch (e: Exception) {
        emptyList()
    }
}

private fun fetchHero(type: String, id: String, tag: String, expect: String = "", indian: Boolean = false): Hero? {
    return try {
        val m = JSONObject(httpGet("$CINEMETA/meta/$type/$id.json")).getJSONObject("meta")
        if (expect.isNotEmpty() && !m.optString("name").lowercase().replace(Regex("[^a-z0-9]"), "").contains(expect)) return null
        var bg = m.optString("background")
        if (bg.isEmpty()) bg = "https://images.metahub.space/background/medium/$id/img"
        var logo = m.optString("logo")
        if (logo.isEmpty()) logo = "https://images.metahub.space/logo/medium/$id/img"
        val gs = m.optJSONArray("genres")
        val genres = if (gs == null) emptyList() else (0 until gs.length()).map { gs.getString(it) }
        Hero(id, type, m.optString("name"), m.optString("releaseInfo").take(4),
            m.optString("imdbRating"), genres, m.optString("description"), bg, tag, logo, indian)
    } catch (e: Exception) {
        null
    }
}

// ---------- Trakt ----------

private const val TRAKT = "https://api.trakt.tv"
const val INDIAN_LANGS = "hi,ta,te,ml,kn,bn,mr,pa,gu"
private val INDIAN_SET = INDIAN_LANGS.split(",").toSet()

class TraktTokens(val access: String, val refresh: String, val expires: Long)
class DeviceCode(val deviceCode: String, val userCode: String, val interval: Int, val expiresIn: Int)
private class Cand(val type: String, val id: String, val lang: String, val tag: String, val ind: Boolean = false)

private fun traktCall(method: String, path: String, id: String, token: String?, body: String?): Pair<Int, String> {
    val c = URL(TRAKT + path).openConnection() as HttpURLConnection
    c.requestMethod = method
    c.connectTimeout = 10000
    c.readTimeout = 20000
    c.setRequestProperty("Content-Type", "application/json")
    c.setRequestProperty("trakt-api-version", "2")
    c.setRequestProperty("trakt-api-key", id)
    if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
    if (body != null) {
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray()) }
    }
    val code = c.responseCode
    val stream = if (code in 200..299) c.inputStream else c.errorStream
    val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
    return Pair(code, text)
}

private fun tokensFrom(j: JSONObject): TraktTokens =
    TraktTokens(
        j.getString("access_token"), j.getString("refresh_token"),
        (j.optLong("created_at", System.currentTimeMillis() / 1000) + j.optLong("expires_in", 7_776_000L)) * 1000L
    )

fun traktDeviceCode(id: String): DeviceCode {
    val r = traktCall("POST", "/oauth/device/code", id, null, JSONObject().put("client_id", id).toString())
    if (r.first != 200) throw IOException("Trakt said " + r.first)
    val j = JSONObject(r.second)
    return DeviceCode(j.getString("device_code"), j.getString("user_code"), j.optInt("interval", 5), j.optInt("expires_in", 600))
}

// null = user has not approved yet
fun traktPollToken(id: String, secret: String, deviceCode: String): TraktTokens? {
    val body = JSONObject().put("code", deviceCode).put("client_id", id).put("client_secret", secret).toString()
    val r = traktCall("POST", "/oauth/device/token", id, null, body)
    return when (r.first) {
        200 -> tokensFrom(JSONObject(r.second))
        400, 429 -> null
        else -> throw IOException("Trakt said " + r.first)
    }
}

private fun traktRefresh(id: String, secret: String, refresh: String): TraktTokens? {
    val body = JSONObject().put("refresh_token", refresh).put("client_id", id).put("client_secret", secret)
        .put("redirect_uri", "urn:ietf:wg:oauth:2.0:oob").put("grant_type", "refresh_token").toString()
    val r = traktCall("POST", "/oauth/token", id, null, body)
    return if (r.first == 200) tokensFrom(JSONObject(r.second)) else null
}

fun ensureTrakt(prefs: Prefs): String? {
    if (prefs.traktId.isEmpty() || prefs.traktAccess.isEmpty()) return null
    if (System.currentTimeMillis() < prefs.traktExpires - 86_400_000L) return prefs.traktAccess
    val t = try { traktRefresh(prefs.traktId, prefs.traktSecret, prefs.traktRefresh) } catch (e: Exception) { null }
    if (t != null) {
        prefs.traktAccess = t.access
        prefs.traktRefresh = t.refresh
        prefs.traktExpires = t.expires
        return t.access
    }
    return prefs.traktAccess
}

private fun traktList(path: String, type: String, tag: String, id: String, token: String?): List<Cand> {
    return try {
        val r = traktCall("GET", path, id, token, null)
        if (r.first != 200) return emptyList()
        val arr = org.json.JSONArray(r.second)
        val out = ArrayList<Cand>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (path.contains("playback") && o.optDouble("progress", 0.0) > 95.0) continue
            val item = o.optJSONObject("movie") ?: o.optJSONObject("show") ?: o
            val imdb = item.optJSONObject("ids")?.optString("imdb") ?: ""
            if (imdb.startsWith("tt")) out.add(Cand(type, imdb, item.optString("language"), tag))
        }
        out
    } catch (e: Exception) {
        emptyList()
    }
}

private class Seed(val id: String, val type: String, val key: String)

// Well-known Indian titles so "Indian first" works even without any account.
// The title is checked against `key` before use, so a wrong ID is simply skipped.
private val INDIAN_SEEDS = listOf(
    Seed("tt8178634", "movie", "rrr"), Seed("tt2631186", "movie", "baahubali"),
    Seed("tt4849438", "movie", "baahubali"), Seed("tt7838252", "movie", "kgf"),
    Seed("tt10698680", "movie", "kgf"), Seed("tt9389998", "movie", "pushpa"),
    Seed("tt16539454", "movie", "kantara"), Seed("tt15354916", "movie", "jawan"),
    Seed("tt12844910", "movie", "pathaan"), Seed("tt5074352", "movie", "dangal"),
    Seed("tt1187043", "movie", "3idiots"), Seed("tt2338151", "movie", "pk"),
    Seed("tt3863552", "movie", "bajrangi"), Seed("tt13751694", "movie", "animal"),
    Seed("tt4430212", "movie", "drishyam"), Seed("tt2395469", "movie", "gullyboy"),
    Seed("tt9115530", "movie", "kabirsingh"), Seed("tt0169102", "movie", "lagaan"),
    Seed("tt0248126", "movie", "kabhikhushi"), Seed("tt0112870", "movie", "dilwale"),
    Seed("tt0073707", "movie", "sholay"), Seed("tt1562872", "movie", "zindaginamilegi"),
    Seed("tt0986264", "movie", "taarezameen"), Seed("tt0367110", "movie", "swades"),
    Seed("tt3322420", "movie", "queen"), Seed("tt8108198", "movie", "andhadhun"),
    Seed("tt8291224", "movie", "uri"), Seed("tt1954470", "movie", "wasseypur"),
    Seed("tt15097216", "movie", "jaibhim"), Seed("tt10189514", "movie", "soorarai"),
    Seed("tt23849204", "movie", "12thfail"), Seed("tt12735488", "movie", "kalki"),
    Seed("tt6998518", "series", "sacredgames"), Seed("tt9544034", "series", "familyman"),
    Seed("tt12004706", "series", "panchayat"), Seed("tt12392504", "series", "scam1992"),
    Seed("tt9432978", "series", "kotafactory")
)

private fun traktWatched(user: String, kind: String, tid: String): List<Pair<String, String>> {
    return try {
        val r = traktCall("GET", "/users/$user/history/$kind?limit=12", tid, null, null)
        if (r.first != 200) return emptyList()
        val arr = org.json.JSONArray(r.second)
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val item = o.optJSONObject("movie") ?: o.optJSONObject("show") ?: continue
            val imdb = item.optJSONObject("ids")?.optString("imdb") ?: ""
            if (imdb.startsWith("tt") && out.none { it.first == imdb }) out.add(Pair(imdb, item.optString("title")))
        }
        out
    } catch (e: Exception) {
        emptyList()
    }
}

private class Pick(val name: String, val type: String, val year: Int, val tag: String)

private fun mv(name: String, year: Int) = Pick(name, "movie", year, "NEW IN INDIA")
private fun sr(name: String) = Pick(name, "series", 0, "SERIES FROM INDIA")

// Good, recent Indian titles. Each is looked up by name in Cinemeta (and checked), so no IDs to get wrong.
private val INDIAN_PICKS = listOf(
    mv("Kalki 2898 AD", 2024), mv("Pushpa 2", 2024), mv("Stree 2", 2024), mv("Laapataa Ladies", 2023),
    mv("Maharaja", 2024), mv("Manjummel Boys", 2024), mv("Premalu", 2024), mv("Salaar", 2023),
    mv("Dunki", 2023), mv("Fighter", 2024), mv("Tiger 3", 2023), mv("Singham Again", 2024),
    mv("Bhool Bhulaiyaa 3", 2024), mv("Crew", 2024), mv("Article 370", 2024), mv("Munjya", 2024),
    mv("Devara", 2024), mv("Lucky Baskhar", 2024), mv("Amaran", 2024), mv("Vettaiyan", 2024),
    mv("Leo", 2023), mv("Jailer", 2023), mv("Saiyaara", 2025), mv("War 2", 2025), mv("Coolie", 2025),
    mv("Chhaava", 2025), mv("Sikandar", 2025), mv("Sky Force", 2025), mv("Kesari Chapter 2", 2025),
    mv("Sitaare Zameen Par", 2025), mv("Thudarum", 2025), mv("Empuraan", 2025), mv("Lokah", 2025),
    mv("Dhurandhar", 2025), mv("Mahavatar Narsimha", 2025), mv("Jolly LLB 3", 2025), mv("Raid 2", 2025),
    mv("Thug Life", 2025), mv("Tourist Family", 2025), mv("Gadar 2", 2023), mv("OMG 2", 2023),
    mv("12th Fail", 2023), mv("Sam Bahadur", 2023), mv("Maidaan", 2024), mv("Shaitaan", 2024),
    mv("Kill", 2024), mv("Chandu Champion", 2024), mv("Aavesham", 2024), mv("Bramayugam", 2024),
    mv("The Goat Life", 2024), mv("Kishkindha Kaandam", 2024), mv("Hanu-Man", 2024),
    mv("Raayan", 2024), mv("Thangalaan", 2024), mv("Meiyazhagan", 2024), mv("Viduthalai", 2023),
    mv("Garudan", 2024), mv("Blue Star", 2024),
    sr("Panchayat"), sr("The Family Man"), sr("Paatal Lok"), sr("Delhi Crime"), sr("Gullak"),
    sr("Kota Factory"), sr("Aspirants"), sr("Scam 1992"), sr("Scam 2003"), sr("Special Ops"),
    sr("Rana Naidu"), sr("Farzi"), sr("Jubilee"), sr("Killer Soup"), sr("Mismatched"),
    sr("Bandish Bandits"), sr("Made in Heaven"), sr("Sacred Games"), sr("Criminal Justice"),
    sr("The Railway Men"), sr("Black Warrant"), sr("Kohrra"), sr("Mirzapur"), sr("Heeramandi"),
    sr("Lootere"), sr("Dahaad"), sr("Rocket Boys"), sr("Undekhi"), sr("Maharani"), sr("Aarya"),
    sr("Jamtara"), sr("Little Things"), sr("Permanent Roommates"), sr("Hostel Daze"),
    sr("Maamla Legal Hai"), sr("Khauf"), sr("Suzhal"), sr("Kerala Crime Files"), sr("Poacher"),
    sr("Trial by Fire"), sr("Mandala Murders"), sr("Taaza Khabar")
)

private fun loadResolved(ctx: Context): HashMap<String, String> {
    val out = HashMap<String, String>()
    try {
        val f = File(ctx.filesDir, "resolved.json")
        if (f.exists()) {
            val j = JSONObject(f.readText())
            for (k in j.keys()) out[k] = j.optString(k)
        }
    } catch (e: Exception) {
    }
    return out
}

private fun saveResolved(ctx: Context, m: Map<String, String>) {
    try {
        val j = JSONObject()
        for ((k, v) in m) j.put(k, v)
        File(ctx.filesDir, "resolved.json").writeText(j.toString())
    } catch (e: Exception) {
    }
}

// Throws IOException only when the network is unreachable.
private fun resolvePick(p: Pick, cache: HashMap<String, String>): String? {
    val k = p.type + ":" + p.name
    val hit = cache[k]
    if (hit != null) return if (hit.isEmpty()) null else hit
    return try {
        val q = URLEncoder.encode(p.name, "UTF-8").replace("+", "%20")
        val arr = JSONObject(httpGet("$CINEMETA/catalog/${p.type}/top/search=$q.json")).optJSONArray("metas")
        val key = p.name.lowercase().replace(Regex("[^a-z0-9]"), "")
        var found: String? = null
        if (arr != null) {
            for (i in 0 until minOf(arr.length(), 8)) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id")
                if (!id.startsWith("tt")) continue
                val n = o.optString("name").lowercase().replace(Regex("[^a-z0-9]"), "")
                val yr = o.optString("releaseInfo").take(4).toIntOrNull()
                val yearOk = p.year == 0 || yr == null || abs(yr - p.year) <= 1
                if (yearOk && (n == key || (key.length >= 6 && n.contains(key)))) {
                    found = id
                    break
                }
            }
        }
        cache[k] = found ?: ""
        found
    } catch (e: FileNotFoundException) {
        cache[k] = ""
        null
    }
}

// region: 0 = India first (Indian titles only), 1 = mixed, 2 = international
// The pick changes every 10 minutes.
fun buildHeroes(
    ctx: Context, types: List<String>, genres: List<String>, region: Int,
    tid: String, user: String, count: Int = 8
): List<Hero> {
    val rnd = Random(System.currentTimeMillis() / 600_000L)
    val indian = ArrayList<Cand>()
    val world = ArrayList<Cand>()
    val expects = HashMap<String, String>()
    fun ind(c: Cand) = Cand(c.type, c.id, c.lang, c.tag, true)
    if (tid.isNotEmpty()) {
        for (t in types) {
            val kind = if (t == "movie") "movies" else "shows"
            if (user.isNotEmpty()) {
                for (w in traktWatched(user, kind, tid).take(3)) {
                    val tag = "BECAUSE YOU WATCHED " + w.second.uppercase()
                    for (c in traktList("/$kind/${w.first}/related?limit=12&extended=full", t, tag, tid, null)) {
                        if (c.lang in INDIAN_SET) indian.add(ind(c)) else world.add(c)
                    }
                }
            }
            traktList("/$kind/trending?limit=30&extended=full&languages=$INDIAN_LANGS", t, "TRENDING IN INDIA", tid, null)
                .shuffled(rnd).take(10).forEach { indian.add(ind(it)) }
        }
    }
    if (region != 2) {
        val resolved = loadResolved(ctx)
        val fresh = ArrayList<Cand>()
        for (p in INDIAN_PICKS.filter { it.type in types }.shuffled(rnd).take(18)) {
            val id = try { resolvePick(p, resolved) } catch (e: IOException) { break }
            if (id != null) fresh.add(Cand(p.type, id, "hi", p.tag, true))
        }
        saveResolved(ctx, resolved)
        for (s in INDIAN_SEEDS.filter { it.type in types }.shuffled(rnd).take(6)) {
            fresh.add(Cand(s.type, s.id, "hi", "ACCLAIMED", true))
            expects[s.id] = s.key
        }
        indian.addAll(fresh.shuffled(rnd))
    }
    for (t in types) {
        for (g in genres) catalogIds(t, g, 12).shuffled(rnd).forEach { world.add(Cand(t, it, "", "POPULAR")) }
        catalogIds(t, null, 12).shuffled(rnd).forEach { world.add(Cand(t, it, "", "POPULAR")) }
    }
    val seq = ArrayList<Cand>()
    when (region) {
        0 -> {
            seq.addAll(indian)
            if (indian.size < count + 4) seq.addAll(world)
        }
        1 -> {
            var ia = 0
            var ib = 0
            while (ia < indian.size || ib < world.size) {
                if (ia < indian.size) { seq.add(indian[ia]); ia++ }
                if (ib < world.size) { seq.add(world[ib]); ib++ }
            }
        }
        else -> seq.addAll(world)
    }
    val picked = LinkedHashMap<String, Cand>()
    for (c in seq) picked.putIfAbsent(c.id, c)
    val out = ArrayList<Hero>()
    for (c in picked.values) {
        val h = fetchHero(c.type, c.id, c.tag, expects[c.id] ?: "", c.ind) ?: continue
        if (h.name.isEmpty()) continue
        val r = h.rating.toDoubleOrNull()
        if (c.ind && r != null && r < 6.8) continue
        out.add(h)
        if (out.size >= count) break
    }
    return out
}

fun saveHeroes(ctx: Context, key: String, list: List<Hero>) {
    val arr = org.json.JSONArray()
    for (h in list) {
        arr.put(
            JSONObject().put("id", h.id).put("type", h.type).put("name", h.name).put("year", h.year)
                .put("rating", h.rating).put("genres", org.json.JSONArray(h.genres))
                .put("overview", h.overview).put("bg", h.bg).put("tag", h.tag).put("logo", h.logo).put("indian", h.indian)
        )
    }
    File(ctx.filesDir, "heroes.json").writeText(
        JSONObject().put("key", key).put("time", System.currentTimeMillis()).put("items", arr).toString()
    )
}

fun loadHeroes(ctx: Context): HeroCache? {
    return try {
        val f = File(ctx.filesDir, "heroes.json")
        if (!f.exists()) return null
        val j = JSONObject(f.readText())
        val arr = j.getJSONArray("items")
        val items = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val gs = o.optJSONArray("genres")
            Hero(
                o.getString("id"), o.getString("type"), o.optString("name"), o.optString("year"),
                o.optString("rating"),
                if (gs == null) emptyList() else (0 until gs.length()).map { gs.getString(it) },
                o.optString("overview"), o.optString("bg"), o.optString("tag"), o.optString("logo"), o.optBoolean("indian")
            )
        }
        HeroCache(j.getString("key"), j.getLong("time"), items)
    } catch (e: Exception) {
        null
    }
}

fun loadHeroImage(ctx: Context, url: String, alpha: Boolean = false): Bitmap? {
    return try {
        val dir = File(ctx.cacheDir, "hero")
        dir.mkdirs()
        val f = File(dir, url.hashCode().toString() + ".img")
        val bytes = if (f.exists()) {
            f.readBytes()
        } else {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.instanceFollowRedirects = true
            val b = c.inputStream.use { it.readBytes() }
            f.writeBytes(b)
            b
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var s = 1
        while (bounds.outWidth / s > (if (alpha) 700 else 1400)) s *= 2
        val o = BitmapFactory.Options().apply {
            inSampleSize = s
            inPreferredConfig = if (alpha) Bitmap.Config.ARGB_8888 else Bitmap.Config.RGB_565
        }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
    } catch (e: Exception) {
        null
    }
}

fun nuvioPackages(ctx: Context): List<Pair<String, String>> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_VIEW, Uri.parse("nuvio://meta?type=movie&id=tt0133093"))
        .addCategory(Intent.CATEGORY_BROWSABLE)
    return pm.queryIntentActivities(i, 0)
        .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        .distinctBy { it.first }
}

fun openInNuvio(ctx: Context, pkg: String?, h: Hero): Boolean {
    val i = Intent(Intent.ACTION_VIEW, Uri.parse("nuvio://meta?type=" + h.type + "&id=" + h.id))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (!pkg.isNullOrEmpty()) i.setPackage(pkg)
    return try {
        ctx.startActivity(i)
        true
    } catch (e: Exception) {
        false
    }
}

// ---------- where "Play" opens a title ----------

class PlayTarget(val pkg: String, val label: String, val scheme: String)

private val BROWSER_WORDS = listOf("browser", "silk", "chrome", "firefox", "internet")

fun playTargets(ctx: Context): List<PlayTarget> {
    val pm = ctx.packageManager
    val out = LinkedHashMap<String, PlayTarget>()
    fun add(uri: String, scheme: String, skipBrowsers: Boolean) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addCategory(Intent.CATEGORY_BROWSABLE)
        for (ri in pm.queryIntentActivities(i, 0)) {
            val p = ri.activityInfo.packageName
            if (p == ctx.packageName || out.containsKey(p)) continue
            val label = ri.loadLabel(pm).toString()
            if (skipBrowsers && BROWSER_WORDS.any { label.contains(it, ignoreCase = true) }) continue
            out[p] = PlayTarget(p, label, scheme)
        }
    }
    add("nuvio://meta?type=movie&id=tt0133093", "nuvio", false)
    add("stremio:///detail/movie/tt0133093", "stremio", false)
    add("https://www.imdb.com/title/tt0133093/", "imdb", true)
    return out.values.toList()
}

fun openTitle(ctx: Context, t: PlayTarget, h: Hero): Boolean {
    val uri = when (t.scheme) {
        "nuvio" -> "nuvio://meta?type=" + h.type + "&id=" + h.id
        "stremio" -> "stremio:///detail/" + h.type + "/" + h.id
        else -> "https://www.imdb.com/title/" + h.id + "/"
    }
    val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        .setPackage(t.pkg)
    return try {
        ctx.startActivity(i)
        true
    } catch (e: Exception) {
        false
    }
}

// ---------- custom (full color) tile images ----------

fun customFile(ctx: Context, pkg: String): File {
    val dir = File(ctx.filesDir, "custom")
    dir.mkdirs()
    return File(dir, "$pkg.png")
}

// Returns null if the link is not a usable picture. Throws IOException when offline.
fun fetchCustomImage(ctx: Context, pkg: String, url: String): Bitmap? {
    val c = URL(url.trim()).openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 20000
    c.instanceFollowRedirects = true
    c.setRequestProperty("User-Agent", "Mozilla/5.0 FireLauncher")
    val bytes = c.inputStream.use { it.readBytes() }
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0) return null
    var s = 1
    while (bounds.outWidth / s > 1400) s *= 2
    val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
        ?: return null
    val k = minOf(1f, 720f / maxOf(raw.width, raw.height))
    val bmp = if (k < 1f) {
        Bitmap.createScaledBitmap(raw, maxOf(1, (raw.width * k).toInt()), maxOf(1, (raw.height * k).toInt()), true)
    } else raw
    customFile(ctx, pkg).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return bmp
}

fun loadCustomImages(ctx: Context): Map<String, Bitmap> {
    val out = HashMap<String, Bitmap>()
    File(ctx.filesDir, "custom").listFiles()?.forEach { f ->
        if (f.name.endsWith(".png")) {
            BitmapFactory.decodeFile(f.path)?.let { out[f.name.removeSuffix(".png")] = it }
        }
    }
    return out
}

fun deleteCustomImage(ctx: Context, pkg: String) {
    customFile(ctx, pkg).delete()
}
