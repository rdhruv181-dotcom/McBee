package com.myfire.launcher

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val THEMES = listOf(
    listOf(Color(0xFF0F1226), Color(0xFF3A1F6E)),
    listOf(Color(0xFF1A0A0A), Color(0xFF6B1414)),
    listOf(Color(0xFF04121F), Color(0xFF0B4A6F)),
    listOf(Color(0xFF07140C), Color(0xFF1B5E3A)),
    listOf(Color(0xFF000000), Color(0xFF161616))
)
val THEME_NAMES = listOf("Midnight", "Crimson", "Ocean", "Forest", "Black")
val SIZE_NAMES = listOf("Small", "Medium", "Large")
val TILE_DIMS = listOf(170 to 96, 220 to 124, 280 to 158)
val SEED = setOf(
    "com.netflix.ninja", "com.amazon.firetv.youtube", "com.google.android.youtube.tv",
    "com.amazon.amazonvideo.livingroom", "com.spotify.tv.android", "com.disney.disneyplus"
)
val ACCENTS = listOf(
    Color(0xFFFFFFFF), Color(0xFF8B6CFF), Color(0xFF00C2FF),
    Color(0xFFFFB300), Color(0xFFFF4081), Color(0xFF2ECC71)
)
val ACCENT_NAMES = listOf("White", "Purple", "Cyan", "Amber", "Pink", "Green")
val RING_NAMES = listOf("White", "Accent", "Gold", "Cyan", "Pink", "Apple glow")
val SHAPE_NAMES = listOf("Square", "Rounded", "Extra round")
val SHAPE_DP = listOf(4, 16, 32)
val FONTS = listOf(FontFamily.Default, FontFamily.SansSerif, FontFamily.Serif, FontFamily.Monospace, FontFamily.Cursive)
val FONT_NAMES = listOf("Default", "Sans", "Serif", "Mono", "Cursive")
val LocalLook = compositionLocalOf { Look() }
val LocalLogos = compositionLocalOf<Map<String, Bitmap>> { emptyMap() }
val BW = Modifier.fillMaxWidth()
val ART_NAMES = listOf("Logo", "Letter", "Banner")
val LOGO_NAMES = listOf("White", "Original")
val CARD_BRUSH = Brush.verticalGradient(listOf(Color(0xFF17171D), Color(0xFF07070A)))

fun ringColor(l: Look): Color = when (l.ring) {
    0 -> Color.White
    1 -> ACCENTS[l.accent]
    2 -> Color(0xFFFFD54F)
    3 -> Color(0xFF00E5FF)
    else -> Color(0xFFFF4081)
}

enum class Screen { HOME, ALLAPPS, OPTIONS, HERO, TRAKT, SETTINGS, APPS, LOOK, WALLPAPER, WEATHER, SLEEP, DEFAULT, DOWNLOAD }

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val status = mutableStateOf("")
    private val sleeping = mutableStateOf(false)
    private var dlId = -1L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id != dlId) return
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                val ok = c.moveToFirst() &&
                    c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL
                if (ok) {
                    status.value = "Downloaded. Opening installer..."
                    installApk(this@MainActivity, apkFile(this@MainActivity))
                } else {
                    status.value = "Download failed. Check the link."
                }
            }
        }
    }

    private fun startDownload(raw: String) {
        val u = raw.trim().let { if (it.startsWith("http")) it else "https://$it" }
        try {
            dlId = enqueueDownload(this, u)
            status.value = "Downloading..."
        } catch (e: Exception) {
            status.value = "Failed: ${e.message}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED
        )
        if (intent?.getBooleanExtra("sleep", false) == true) sleeping.value = true
        val prefs = Prefs(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherApp(prefs, tick.intValue, status.value, sleeping.value, { sleeping.value = it }) {
                    startDownload(it)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("sleep", false)) sleeping.value = true
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }
}

@Composable
fun LauncherApp(
    prefs: Prefs, refresh: Int, status: String,
    sleeping: Boolean, setSleeping: (Boolean) -> Unit, onDownload: (String) -> Unit
) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var hidden by remember { mutableStateOf(prefs.hidden) }
    var favs by remember { mutableStateOf(prefs.favs) }
    var order by remember { mutableStateOf(prefs.order) }
    var tile by remember { mutableIntStateOf(prefs.tileSize) }
    var theme by remember { mutableIntStateOf(prefs.theme) }
    var look by remember { mutableStateOf(prefs.look) }
    var wx by remember { mutableStateOf(prefs.wx) }
    var weather by remember { mutableStateOf("") }
    var all by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var wallpaper by remember { mutableStateOf<Bitmap?>(null) }
    var bg by remember { mutableStateOf<Bitmap?>(null) }
    var modes by remember { mutableStateOf(prefs.artModes) }
    var logos by remember { mutableStateOf<Map<String, Bitmap>>(emptyMap()) }
    var cinematic by remember { mutableStateOf(prefs.cinematic) }
    var heroPkg by remember { mutableStateOf(prefs.heroPkg) }
    var heroTypes by remember { mutableIntStateOf(prefs.heroTypes) }
    var heroGenres by remember { mutableStateOf(prefs.heroGenres) }
    var taste by remember { mutableStateOf(prefs.taste) }
    var heroes by remember { mutableStateOf<List<Hero>>(emptyList()) }
    var heroImgs by remember { mutableStateOf<Map<String, Bitmap>>(emptyMap()) }
    var heroIdx by remember { mutableIntStateOf(0) }
    var heroStatus by remember { mutableStateOf("") }
    var heroTick by remember { mutableIntStateOf(0) }
    var region by remember { mutableIntStateOf(prefs.region) }
    var traktId by remember { mutableStateOf(prefs.traktId) }
    var traktSecret by remember { mutableStateOf(prefs.traktSecret) }
    var traktOn by remember { mutableStateOf(prefs.traktAccess.isNotEmpty()) }
    var heroLogos by remember { mutableStateOf<Map<String, Bitmap>>(emptyMap()) }
    val targets = remember(refresh) { playTargets(ctx) }
    val target = targets.firstOrNull { it.pkg == heroPkg } ?: targets.firstOrNull()
    val feedGenres = (heroGenres.toList() + topTaste(taste)).distinct().take(3)
    val heroKey = "$region|$heroTypes|" + feedGenres.joinToString(",") + "|" +
        (System.currentTimeMillis() / 86_400_000L) + "|" + (if (traktId.isEmpty()) 0 else 1) + (if (traktOn) 1 else 0)
    var optPkg by remember { mutableStateOf<String?>(null) }
    var optBack by remember { mutableStateOf(Screen.APPS) }
    val openOptions: (String) -> Unit = { p -> optPkg = p; optBack = screen; screen = Screen.OPTIONS }

    LaunchedEffect(refresh) { all = withContext(Dispatchers.IO) { loadApps(ctx) } }
    LaunchedEffect(Unit) { wallpaper = withContext(Dispatchers.IO) { loadWallpaper(ctx) } }
    LaunchedEffect(wallpaper, look.blur) {
        bg = wallpaper?.let { w -> withContext(Dispatchers.Default) { gaussianBlur(w, look.blur) } }
    }
    LaunchedEffect(wx, refresh) {
        weather = if (wx.on && wx.city.isNotBlank()) {
            (withContext(Dispatchers.IO) { fetchWeather(wx) }) ?: weather
        } else ""
    }
    LaunchedEffect(Unit) { logos = withContext(Dispatchers.IO) { loadOnlineLogos(ctx) } }
    LaunchedEffect(heroKey, cinematic, heroTick) {
        if (!cinematic) return@LaunchedEffect
        val cached = withContext(Dispatchers.IO) { loadHeroes(ctx) }
        if (cached != null && heroes.isEmpty()) heroes = cached.items
        val fresh = cached != null && heroTick == 0 && cached.key == heroKey &&
            System.currentTimeMillis() - cached.time < 12 * 3600_000L
        if (!fresh) {
            heroStatus = "Updating picks..."
            val types = when (heroTypes) {
                1 -> listOf("movie")
                2 -> listOf("series")
                else -> listOf("movie", "series")
            }
            val list = try {
                withContext(Dispatchers.IO) { buildHeroes(types, feedGenres, region, traktId, ensureTrakt(prefs)) }
            } catch (e: java.io.IOException) {
                emptyList()
            }
            if (list.isNotEmpty()) {
                heroes = list
                heroIdx = 0
                withContext(Dispatchers.IO) { saveHeroes(ctx, heroKey, list) }
                heroStatus = "Picks updated."
            } else {
                heroStatus = "Couldn't update picks. Check the internet."
            }
        }
    }
    LaunchedEffect(heroes) {
        heroImgs = heroImgs.filterKeys { k -> heroes.any { it.id == k } }
        heroLogos = heroLogos.filterKeys { k -> heroes.any { it.id == k } }
        for (h in heroes) {
            if (!heroImgs.containsKey(h.id)) {
                val b = withContext(Dispatchers.IO) { loadHeroImage(ctx, h.bg) }
                if (b != null) heroImgs = heroImgs + (h.id to b)
            }
            if (h.logo.isNotEmpty() && !heroLogos.containsKey(h.id)) {
                val l = withContext(Dispatchers.IO) { loadHeroImage(ctx, h.logo, true) }
                if (l != null) heroLogos = heroLogos + (h.id to l)
            }
        }
    }
    LaunchedEffect(all) {
        if (all.isEmpty()) return@LaunchedEffect
        delay(1500)
        for (a in all) {
            if (logos.containsKey(a.pkg) || a.pkg in prefs.triedLogos) continue
            val bmp = try {
                withContext(Dispatchers.IO) { findLogo(ctx, a.pkg, a.label, a.pkg, true) }
            } catch (e: java.io.IOException) {
                break
            }
            if (bmp != null) logos = logos + (a.pkg to bmp) else prefs.triedLogos = prefs.triedLogos + a.pkg
        }
    }
    LaunchedEffect(all) {
        if (!prefs.seeded && all.isNotEmpty()) {
            prefs.seeded = true
            if (favs.isEmpty()) {
                val m = all.filter { it.pkg in SEED }.map { it.pkg }.toSet()
                if (m.isNotEmpty()) { favs = m; prefs.favs = m }
            }
        }
    }
    val sorted = remember(all, order) { sortApps(all, order) }
    val visible = remember(sorted, hidden) { sorted.filter { it.pkg !in hidden } }
    val favList = remember(visible, favs) { visible.filter { it.pkg in favs } }
    val otherList = remember(visible, favs) { visible.filter { it.pkg !in favs } }

    BackHandler {
        screen = when (screen) {
            Screen.HOME, Screen.SETTINGS, Screen.ALLAPPS -> Screen.HOME
            Screen.OPTIONS -> optBack
            Screen.TRAKT -> Screen.HERO
            else -> Screen.SETTINGS
        }
    }

    CompositionLocalProvider(LocalLook provides look, LocalLogos provides logos) {
        ProvideTextStyle(TextStyle(fontFamily = FONTS[look.font])) {
            Box(Modifier.fillMaxSize().let { if (bg == null) it.background(Brush.verticalGradient(THEMES[theme])) else it }) {
                bg?.let { b ->
                    val img = remember(b) { b.asImageBitmap() }
                    val extra = when (screen) {
                        Screen.HOME -> 0f
                        Screen.ALLAPPS -> 0.4f
                        else -> 0.68f
                    }
                    val a = 1f - (1f - look.dark / 10f) * (1f - extra)
                    Image(
                        img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                        colorFilter = ColorFilter.tint(Color.Black.copy(alpha = a), BlendMode.SrcAtop)
                    )
                }
                when (screen) {
                    Screen.HOME -> if (cinematic) {
                        CinematicHome(
                            heroes, heroImgs, heroLogos, heroIdx,
                            onNext = { if (heroes.isNotEmpty()) heroIdx = (heroIdx + 1) % heroes.size },
                            onPrev = { if (heroes.isNotEmpty()) heroIdx = (heroIdx - 1 + heroes.size) % heroes.size },
                            onPlay = { h ->
                                taste = learnTaste(taste, h.genres)
                                prefs.taste = taste
                                if (target == null || !openTitle(ctx, target, h)) {
                                    Toast.makeText(ctx, "No app available to play this. Install Nuvio or choose one in Settings > Recommendations.", Toast.LENGTH_LONG).show()
                                }
                            },
                            favs = favList, tileSize = tile, modes = modes, online = isOnline(ctx), weather = weather,
                            onSettings = { screen = Screen.SETTINGS },
                            onAll = { screen = Screen.ALLAPPS },
                            onOptions = openOptions
                        )
                    } else {
                        Home(
                            favList, tile, modes, isOnline(ctx), weather,
                            onSettings = { screen = Screen.SETTINGS },
                            onAll = { screen = Screen.ALLAPPS },
                            onOptions = openOptions
                        )
                    }
                    Screen.ALLAPPS -> AllAppsScreen(otherList, modes, openOptions) { screen = Screen.HOME }
                    Screen.SETTINGS -> SettingsScreen(
                        tile, theme,
                        go = { screen = it },
                        onTile = { tile = (tile + 1) % 3; prefs.tileSize = tile },
                        onTheme = { theme = (theme + 1) % THEMES.size; prefs.theme = theme },
                        onBack = { screen = Screen.HOME }
                    )
                    Screen.APPS -> AppsScreen(
                        sorted, hidden, favs,
                        onToggle = { p ->
                            hidden = if (p in hidden) hidden - p else hidden + p
                            prefs.hidden = hidden
                        },
                        onFav = { p ->
                            favs = if (p in favs) favs - p else favs + p
                            prefs.favs = favs
                        },
                        onManage = openOptions,
                        onMove = { from, to ->
                            if (to in sorted.indices) {
                                val l = sorted.map { it.pkg }.toMutableList()
                                val t = l[from]; l[from] = l[to]; l[to] = t
                                order = l; prefs.order = l
                            }
                        },
                        onBack = { screen = Screen.SETTINGS }
                    )
                    Screen.OPTIONS -> {
                        val target = all.firstOrNull { it.pkg == optPkg }
                        if (target == null) {
                            LaunchedEffect(Unit) { screen = optBack }
                        } else {
                            AppOptionsScreen(
                                target, modes[target.pkg] ?: 0,
                                onMode = {
                                    modes = modes + (target.pkg to (((modes[target.pkg] ?: 0) + 1) % 3))
                                    prefs.artModes = modes
                                },
                                onFetch = { input ->
                                    try {
                                        val bmp = withContext(Dispatchers.IO) {
                                            findLogo(ctx, target.pkg, input, "", false)
                                        }
                                        if (bmp != null) {
                                            logos = logos + (target.pkg to bmp)
                                            "Logo updated."
                                        } else {
                                            "No logo found. Try another spelling, or paste a direct image link."
                                        }
                                    } catch (e: java.io.IOException) {
                                        "Network problem (" + e.javaClass.simpleName + "). Check the internet and try again."
                                    }
                                },
                                onResetLogo = {
                                    deleteOnlineLogo(ctx, target.pkg)
                                    logos = logos - target.pkg
                                    prefs.triedLogos = prefs.triedLogos + target.pkg
                                },
                                onBack = { screen = optBack }
                            )
                        }
                    }
                    Screen.HERO -> HeroSettingsScreen(
                        cinematic, { cinematic = !cinematic; prefs.cinematic = cinematic },
                        targets, target?.label ?: "none found",
                        {
                            if (targets.isNotEmpty()) {
                                val i = targets.indexOfFirst { it.pkg == target?.pkg }
                                heroPkg = targets[(i + 1) % targets.size].pkg
                                prefs.heroPkg = heroPkg
                            }
                        },
                        region, { region = (region + 1) % 3; prefs.region = region },
                        heroTypes, { heroTypes = (heroTypes + 1) % 3; prefs.heroTypes = heroTypes },
                        heroGenres,
                        { g ->
                            heroGenres = if (g in heroGenres) heroGenres - g else heroGenres + g
                            prefs.heroGenres = heroGenres
                        },
                        taste, { taste = emptyMap(); prefs.taste = taste },
                        traktOn, { screen = Screen.TRAKT },
                        { heroTick++ }, heroStatus
                    ) { screen = Screen.SETTINGS }
                    Screen.TRAKT -> TraktScreen(
                        traktId, traktSecret, traktOn,
                        { traktId = it; prefs.traktId = it },
                        { traktSecret = it; prefs.traktSecret = it },
                        { t ->
                            prefs.traktAccess = t.access
                            prefs.traktRefresh = t.refresh
                            prefs.traktExpires = t.expires
                            traktOn = true
                            heroTick++
                        },
                        { prefs.traktAccess = ""; prefs.traktRefresh = ""; traktOn = false; heroTick++ }
                    ) { screen = Screen.HERO }
                    Screen.LOOK -> LookScreen(look, { look = it; prefs.look = it }) { screen = Screen.SETTINGS }
                    Screen.WALLPAPER -> WallpaperScreen({ wallpaper = it }) { screen = Screen.SETTINGS }
                    Screen.WEATHER -> WeatherScreen(wx, { wx = it; prefs.wx = it }) { screen = Screen.SETTINGS }
                    Screen.SLEEP -> SleepSettings(prefs, all.map { it.pkg }, { setSleeping(true) }) { screen = Screen.SETTINGS }
                    Screen.DEFAULT -> DefaultHomeScreen { screen = Screen.SETTINGS }
                    Screen.DOWNLOAD -> DownloadScreen(status, onDownload) { screen = Screen.SETTINGS }
                }
                if (sleeping) SleepScreen { setSleeping(false) }
            }
        }
    }
}

// ---------- shared pieces ----------

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val accent = ACCENTS[LocalLook.current.accent]
    val fg = if (accent.luminance() > 0.35f) Color.Black else Color.White
    var f by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (f) accent else Color(0x1FFFFFFF))
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 13.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text, color = if (f) fg else Color.White, fontSize = 20.sp, maxLines = 1)
    }
}

@Composable
fun SettingRow(label: String, value: String = "", modifier: Modifier = Modifier, onClick: () -> Unit) {
    val accent = ACCENTS[LocalLook.current.accent]
    val fg = if (accent.luminance() > 0.35f) Color.Black else Color.White
    var f by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (f) 1.025f else 1f, tween(110), label = "sr")
    Row(
        modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(16.dp))
            .background(if (f) accent else Color(0x14FFFFFF))
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val c = if (f) fg else Color.White
        Text(label, color = c, fontSize = 20.sp, modifier = Modifier.weight(1f), maxLines = 1)
        if (value.isNotEmpty()) {
            Text(
                value, color = c.copy(alpha = 0.7f), fontSize = 18.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 360.dp)
            )
        }
        Text("  \u203A", color = c.copy(alpha = 0.7f), fontSize = 22.sp)
    }
}

@Composable
fun Page(content: LazyListScope.() -> Unit) {
    val shape = RoundedCornerShape(32.dp)
    Box(Modifier.fillMaxSize().padding(top = 20.dp, bottom = 36.dp), contentAlignment = Alignment.TopCenter) {
        Box(
            Modifier.widthIn(max = 780.dp).fillMaxHeight().clip(shape)
                .background(Color(0x40000000))
                .border(1.dp, Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color(0x0FFFFFFF))), shape)
        ) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 28.dp, vertical = 28.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                content = content
            )
        }
    }
}

fun LazyListScope.title(t: String) {
    item { Text(t, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Light) }
}

fun LazyListScope.header(t: String) {
    item {
        Text(
            t, color = Color(0x99FFFFFF), fontSize = 13.sp, letterSpacing = 2.sp,
            modifier = Modifier.padding(top = 16.dp, start = 6.dp)
        )
    }
}

fun LazyListScope.note(t: String) {
    item { Text(t, color = Color(0xCCFFFFFF), fontSize = 18.sp) }
}

@Composable
fun Field(value: String, hint: String, onChange: (String) -> Unit) {
    var editing by remember { mutableStateOf(false) }
    var restore by remember { mutableStateOf(false) }
    val rowFr = remember { FocusRequester() }
    val fieldFr = remember { FocusRequester() }
    LaunchedEffect(editing) {
        delay(60)
        if (editing) {
            runCatching { fieldFr.requestFocus() }
        } else if (restore) {
            restore = false
            runCatching { rowFr.requestFocus() }
        }
    }
    if (!editing) {
        SettingRow(hint, if (value.isEmpty()) "press OK to type" else value, Modifier.focusRequester(rowFr)) {
            editing = true
        }
    } else {
        var gained by remember { mutableStateOf(false) }
        OutlinedTextField(
            value = value, onValueChange = onChange, singleLine = true,
            label = { Text(hint) },
            textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { restore = true; editing = false }),
            modifier = Modifier.fillMaxWidth().focusRequester(fieldFr).onFocusChanged {
                if (it.isFocused) gained = true else if (gained) editing = false
            }
        )
    }
}

@Composable
fun Stepper(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(
        BW.clip(RoundedCornerShape(14.dp)).background(Color(0x1AFFFFFF)).padding(start = 22.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color(0xB3FFFFFF), fontSize = 18.sp)
        Btn("-", onClick = onMinus)
        Btn("+", onClick = onPlus)
    }
}

// ---------- icons ----------

@Composable
fun WifiIcon(on: Boolean) {
    Canvas(Modifier.size(24.dp)) {
        val c = Color.White.copy(alpha = if (on) 0.95f else 0.35f)
        val cx = size.width / 2f
        val cy = size.height * 0.88f
        val sw = size.width * 0.09f
        for (i in 1..3) {
            val rad = size.width * 0.22f * i
            drawArc(
                color = c, startAngle = 225f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - rad, cy - rad), size = Size(rad * 2f, rad * 2f),
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
        }
        drawCircle(c, radius = sw * 0.9f, center = Offset(cx, cy))
    }
}

@Composable
fun TuneIcon(color: Color) {
    Canvas(Modifier.size(24.dp)) {
        val sw = size.width * 0.08f
        val ys = listOf(0.26f, 0.5f, 0.74f)
        val ks = listOf(0.66f, 0.34f, 0.7f)
        for (j in 0..2) {
            val y = size.height * ys[j]
            drawLine(color, Offset(size.width * 0.12f, y), Offset(size.width * 0.88f, y), strokeWidth = sw, cap = StrokeCap.Round)
            drawCircle(color, radius = size.width * 0.1f, center = Offset(size.width * ks[j], y))
        }
    }
}

@Composable
fun GridIcon(color: Color, dim: Float) {
    Canvas(Modifier.size(dim.dp)) {
        val s = size.width * 0.4f
        val gap = size.width * 0.2f
        for (r in 0..1) for (c in 0..1) {
            drawRoundRect(
                color, topLeft = Offset(c * (s + gap), r * (s + gap)), size = Size(s, s),
                cornerRadius = CornerRadius(s * 0.25f)
            )
        }
    }
}

@Composable
fun IconBtn(onClick: () -> Unit, icon: @Composable (Color) -> Unit) {
    val accent = ACCENTS[LocalLook.current.accent]
    val fg = if (accent.luminance() > 0.35f) Color.Black else Color.White
    var f by remember { mutableStateOf(false) }
    Box(
        Modifier.size(44.dp).clip(CircleShape)
            .background(if (f) accent else Color(0x26FFFFFF))
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { icon(if (f) fg else Color.White) }
}

// ---------- home ----------

@Composable
fun Home(
    favs: List<AppItem>, tileSize: Int, modes: Map<String, Int>, online: Boolean, weather: String,
    onSettings: () -> Unit, onAll: () -> Unit, onOptions: (String) -> Unit
) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(10_000) } }
    val hm = remember(now) { SimpleDateFormat("h:mm", Locale.getDefault()).format(Date(now)) }
    val ap = remember(now) { SimpleDateFormat("a", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date(now)).uppercase() }
    val ctx = LocalContext.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(favs.size) { delay(150); runCatching { fr.requestFocus() } }
    val (w, h) = TILE_DIMS[tileSize]
    val panel = RoundedCornerShape(30.dp)

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(320.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
        )
        Column(Modifier.fillMaxSize().padding(start = 36.dp, end = 36.dp, top = 22.dp, bottom = 36.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.Top) {
                Column {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(hm, color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.Light)
                        Text(ap, color = Color(0xCCFFFFFF), fontSize = 28.sp, modifier = Modifier.padding(start = 10.dp, bottom = 16.dp))
                    }
                    Text(date, color = Color(0xCCFFFFFF), fontSize = 20.sp, letterSpacing = 2.sp)
                    if (weather.isNotEmpty()) {
                        Text(weather, color = Color(0xCCFFFFFF), fontSize = 22.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                Spacer(Modifier.weight(1f))
                StatusPill(online, onSettings)
            }
            Spacer(Modifier.weight(1f))
            Text(
                if (favs.isEmpty()) "NO PINNED APPS YET - SETTINGS > APPS > PIN" else "FAVORITES",
                color = Color(0xB3FFFFFF), fontSize = 14.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 20.dp, bottom = 8.dp)
            )
            Box(
                Modifier.fillMaxWidth().clip(panel)
                    .background(Color(0x73000000))
                    .border(1.dp, Color(0x26FFFFFF), panel)
            ) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    itemsIndexed(favs, key = { _, a -> a.pkg }) { i, a ->
                        Tile(
                            a, w, h, modes[a.pkg] ?: 0,
                            if (i == 0) Modifier.focusRequester(fr) else Modifier,
                            onMenu = { onOptions(a.pkg) }
                        ) { launchApp(ctx, a.pkg) }
                    }
                    item(key = "__all") {
                        TileFrame(w, h, "All apps", if (favs.isEmpty()) Modifier.focusRequester(fr) else Modifier, onAll) {
                            GridIcon(Color.White, h * 0.4f)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusPill(online: Boolean, onSettings: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier.clip(shape).background(Color(0x55000000)).border(1.dp, Color(0x22FFFFFF), shape)
            .padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        WifiIcon(online)
        IconBtn(onSettings) { TuneIcon(it) }
    }
}

@Composable
fun TileFrame(
    w: Int, h: Int, label: String, modifier: Modifier, onClick: () -> Unit,
    onFocused: (() -> Unit)? = null,
    onMenu: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val look = LocalLook.current
    val apple = look.ring == 5
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) (if (apple) 1.1f else 1.07f) else 1f, tween(130), label = "scale")
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(130), label = "glow")
    val ring = ringColor(look)
    val shape = RoundedCornerShape(SHAPE_DP[look.shape].dp)
    val edge = if (apple) (if (focused) Color(0x99FFFFFF) else Color(0x22FFFFFF)) else (if (focused) ring else Color(0x22FFFFFF))
    val edgeW = if (focused) (if (apple) 2.dp else 3.dp) else 1.dp
    Column(Modifier.width(w.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier
                .size(w.dp, h.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .drawBehind {
                    if (apple && glow > 0f) {
                        drawRect(
                            brush = Brush.radialGradient(
                                listOf(Color(0xB3000000), Color.Transparent),
                                center = Offset(size.width / 2f, size.height * 0.9f),
                                radius = size.width * 0.8f
                            ),
                            topLeft = Offset(-size.width * 0.2f, size.height * 0.15f),
                            size = Size(size.width * 1.4f, size.height * 1.1f),
                            alpha = glow
                        )
                    }
                }
                .clip(shape)
                .background(CARD_BRUSH)
                .border(edgeW, edge, shape)
                .onFocusChanged {
                    focused = it.isFocused
                    if (it.isFocused) onFocused?.invoke()
                }
                .onKeyEvent { e ->
                    if (onMenu != null && e.key == Key.Menu && e.type == KeyEventType.KeyUp) {
                        onMenu()
                        true
                    } else false
                }
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            content()
            if (apple) {
                Box(
                    Modifier.fillMaxSize().graphicsLayer { alpha = glow }
                        .background(Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color(0x00FFFFFF))))
                )
            }
        }
        Text(
            label, color = if (focused) Color.White else Color(0xCCFFFFFF), fontSize = 15.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 12.dp)
        )
    }
}

@Composable
fun TileArt(item: AppItem, w: Int, h: Int, mode: Int) {
    val look = LocalLook.current
    val online = LocalLogos.current[item.pkg]
    val bmp = remember(item, online, mode, look.logo) {
        when (mode) {
            1 -> null
            2 -> item.banner ?: item.color
            else -> if (look.logo == 0) (online ?: item.white) else item.color
        }
    }
    val img = remember(bmp) { bmp?.asImageBitmap() }
    val full = mode == 2 && item.banner != null
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (img == null) {
            Text(item.label.take(1).uppercase(), color = Color.White, fontSize = (h * 0.42f).sp, fontWeight = FontWeight.Light)
        } else if (full) {
            Image(img, item.label, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Image(
                img, item.label,
                Modifier.fillMaxSize().padding(horizontal = (w * 0.2f).dp, vertical = (h * 0.22f).dp),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
fun Tile(
    item: AppItem, w: Int, h: Int, mode: Int, modifier: Modifier,
    onFocused: (() -> Unit)? = null, onMenu: (() -> Unit)? = null, onClick: () -> Unit
) {
    TileFrame(w, h, item.label, modifier, onClick, onFocused, onMenu) { TileArt(item, w, h, mode) }
}

@Composable
fun AllAppsScreen(apps: List<AppItem>, modes: Map<String, Int>, onOptions: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val state = rememberLazyListState()
    val fr = remember { FocusRequester() }
    LaunchedEffect(apps.size) { if (apps.isNotEmpty()) { delay(150); runCatching { fr.requestFocus() } } }
    Column(Modifier.fillMaxSize().padding(top = 26.dp, bottom = 30.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 56.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("All apps", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Light)
                Text("${apps.size} APPS  -  PRESS MENU ON AN APP FOR OPTIONS", color = Color(0xB3FFFFFF), fontSize = 12.sp, letterSpacing = 1.5.sp)
            }
            Btn("Back", onClick = onBack)
        }
        if (apps.isEmpty()) {
            Text(
                "Every app is pinned to the home page or hidden.", color = Color(0xCCFFFFFF), fontSize = 18.sp,
                modifier = Modifier.padding(56.dp)
            )
        }
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val gap = 16.dp
            val top = 12.dp
            val labelH = 34.dp
            val rowH = (maxHeight - top - gap * 2) / 3
            val tileH = rowH - labelH
            val tileW = tileH * 16f / 9f
            val cols = maxOf(3, ((maxWidth - 112.dp + gap) / (tileW + gap)).toInt())
            val rows = remember(apps, cols) { apps.chunked(cols) }
            LazyColumn(
                state = state,
                contentPadding = PaddingValues(start = 56.dp, end = 56.dp, top = top),
                verticalArrangement = Arrangement.spacedBy(gap)
            ) {
                itemsIndexed(rows, key = { _, row -> row.first().pkg }) { r, row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                        row.forEachIndexed { c, a ->
                            Tile(
                                a, tileW.value.toInt(), tileH.value.toInt(), modes[a.pkg] ?: 0,
                                if (r == 0 && c == 0) Modifier.focusRequester(fr) else Modifier,
                                onFocused = { scope.launch { state.animateScrollToItem(maxOf(0, r - 1)) } },
                                onMenu = { onOptions(a.pkg) }
                            ) { launchApp(ctx, a.pkg) }
                        }
                    }
                }
            }
        }
    }
}

// ---------- settings screens ----------

@Composable
fun SettingsScreen(
    tile: Int, theme: Int, go: (Screen) -> Unit,
    onTile: () -> Unit, onTheme: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Page {
        title("Settings")
        header("HOME SCREEN")
        item { SettingRow("Apps: pin, hide, reorder", "", Modifier.focusRequester(fr)) { go(Screen.APPS) } }
        item { SettingRow("Tile size", SIZE_NAMES[tile], onClick = onTile) }
        item { SettingRow("Recommendations & home style") { go(Screen.HERO) } }
        header("APPEARANCE")
        item { SettingRow("Look & feel") { go(Screen.LOOK) } }
        item { SettingRow("Wallpaper") { go(Screen.WALLPAPER) } }
        item { SettingRow("Background", THEME_NAMES[theme], onClick = onTheme) }
        header("EXTRAS")
        item { SettingRow("Weather") { go(Screen.WEATHER) } }
        item { SettingRow("Sleep timer & clear RAM") { go(Screen.SLEEP) } }
        header("SYSTEM")
        item { SettingRow("Make this my default home") { go(Screen.DEFAULT) } }
        item { SettingRow("Download & install an APK") { go(Screen.DOWNLOAD) } }
        item {
            SettingRow("Fire TV system settings") {
                ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        item { Spacer(Modifier.height(8.dp)); Btn("Back", BW, onBack) }
    }
}

@Composable
fun AppsScreen(
    apps: List<AppItem>, hidden: Set<String>, favs: Set<String>,
    onToggle: (String) -> Unit, onFav: (String) -> Unit, onManage: (String) -> Unit,
    onMove: (Int, Int) -> Unit, onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val state = rememberLazyListState()
    val panel = RoundedCornerShape(32.dp)
    Box(Modifier.fillMaxSize().padding(top = 20.dp, bottom = 36.dp), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 960.dp).fillMaxHeight().padding(horizontal = 24.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Apps", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Light)
                    Text("PINNED APPS SHOW ON HOME. THE REST GO TO ALL APPS.", color = Color(0xB3FFFFFF), fontSize = 12.sp, letterSpacing = 1.5.sp)
                }
                Btn("Done", onClick = onBack)
            }
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.weight(1f).fillMaxWidth().clip(panel).background(Color(0x40000000))
                    .border(1.dp, Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color(0x0FFFFFFF))), panel)
            ) {
                LazyColumn(
                    state = state,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(apps, key = { _, a -> a.pkg }) { idx, a ->
                        Row(
                            Modifier.fillMaxWidth().onFocusChanged {
                                if (it.hasFocus) scope.launch { state.animateScrollToItem(maxOf(0, idx - 2)) }
                            },
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(72.dp, 44.dp).clip(RoundedCornerShape(12.dp)).background(CARD_BRUSH)
                                    .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(12.dp))
                            ) { TileArt(a, 72, 44, 0) }
                            Btn((if (a.pkg in hidden) "Hidden   " else "Shown    ") + a.label, Modifier.weight(1f)) {
                                onToggle(a.pkg)
                            }
                            Btn(if (a.pkg in favs) "Unpin" else "Pin") { onFav(a.pkg) }
                            Btn("Manage") { onManage(a.pkg) }
                            Btn("Up") { onMove(idx, idx - 1) }
                            Btn("Down") { onMove(idx, idx + 1) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppOptionsScreen(
    item: AppItem, mode: Int, onMode: () -> Unit,
    onFetch: suspend (String) -> String, onResetLogo: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(item.label) }
    var msg by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    val version = remember(item.pkg) {
        try { ctx.packageManager.getPackageInfo(item.pkg, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    val cardShape = RoundedCornerShape(SHAPE_DP[LocalLook.current.shape].dp)
    val panel = RoundedCornerShape(32.dp)
    Row(
        Modifier.fillMaxSize().padding(start = 56.dp, end = 40.dp, top = 28.dp, bottom = 36.dp),
        horizontalArrangement = Arrangement.spacedBy(40.dp)
    ) {
        Column(Modifier.width(300.dp)) {
            Box(
                Modifier.size(300.dp, 169.dp).clip(cardShape).background(CARD_BRUSH)
                    .border(1.dp, Color(0x33FFFFFF), cardShape)
            ) { TileArt(item, 300, 169, mode) }
            Text(item.label, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light, maxLines = 2, modifier = Modifier.padding(top = 20.dp))
            Text(item.pkg, color = Color(0x99FFFFFF), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            if (version.isNotEmpty()) {
                Text("VERSION $version", color = Color(0xB3FFFFFF), fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }
        Box(
            Modifier.weight(1f).fillMaxHeight().clip(panel).background(Color(0x40000000))
                .border(1.dp, Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color(0x0FFFFFFF))), panel)
        ) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                header("ICON")
                item { SettingRow("Icon style", ART_NAMES[mode], Modifier.focusRequester(fr), onMode) }
                note("Type a brand name, or paste a direct link to a logo image (png or svg).")
                item { Field(name, "Brand name or image link") { name = it } }
                item {
                    SettingRow("Find logo online") {
                        scope.launch {
                            msg = "Searching..."
                            msg = onFetch(name.trim())
                        }
                    }
                }
                item { SettingRow("Use the app's own logo") { onResetLogo(); msg = "Using the app's own logo." } }
                header("APP")
                item {
                    SettingRow("Uninstall") {
                        ctx.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:" + item.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
                item {
                    SettingRow("App info") {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + item.pkg))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
                if (msg.isNotEmpty()) item { Text(msg, color = Color(0xFF9BE7A1), fontSize = 18.sp) }
                item { Spacer(Modifier.height(4.dp)); Btn("Back", BW, onBack) }
            }
        }
    }
}

@Composable
fun LookScreen(look: Look, onChange: (Look) -> Unit, onBack: () -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Page {
        title("Look & feel")
        item {
            SettingRow("Accent color", ACCENT_NAMES[look.accent], Modifier.focusRequester(fr)) {
                onChange(look.copy(accent = (look.accent + 1) % ACCENTS.size))
            }
        }
        item { SettingRow("Focus ring", RING_NAMES[look.ring]) { onChange(look.copy(ring = (look.ring + 1) % RING_NAMES.size)) } }
        item { SettingRow("Tile shape", SHAPE_NAMES[look.shape]) { onChange(look.copy(shape = (look.shape + 1) % SHAPE_NAMES.size)) } }
        item { SettingRow("Font", FONT_NAMES[look.font]) { onChange(look.copy(font = (look.font + 1) % FONTS.size)) } }
        item { SettingRow("Logo color", LOGO_NAMES[look.logo]) { onChange(look.copy(logo = (look.logo + 1) % 2)) } }
        item {
            Stepper("Wallpaper darkness", "${look.dark * 10}%",
                { onChange(look.copy(dark = (look.dark - 1).coerceAtLeast(0))) },
                { onChange(look.copy(dark = (look.dark + 1).coerceAtMost(10))) })
        }
        item {
            Stepper("Wallpaper blur", "${look.blur} / ${SIGMAS.size - 1}",
                { onChange(look.copy(blur = (look.blur - 1).coerceAtLeast(0))) },
                { onChange(look.copy(blur = (look.blur + 1).coerceAtMost(SIGMAS.size - 1))) })
        }
        item { Spacer(Modifier.height(8.dp)); Btn("Back", BW, onBack) }
    }
}

@Composable
fun WallpaperScreen(onSet: (Bitmap?) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Page {
        title("Wallpaper")
        note("Enter a direct link to an image (.jpg or .png).")
        item { Field(url, "https://example.com/wallpaper.jpg") { url = it } }
        item {
            Btn("Set wallpaper", BW) {
                if (url.isNotBlank()) {
                    msg = "Downloading..."
                    val u = url.trim().let { if (it.startsWith("http")) it else "https://$it" }
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { downloadWallpaper(ctx, u) }
                        if (ok) {
                            onSet(withContext(Dispatchers.IO) { loadWallpaper(ctx) })
                            msg = "Wallpaper set!"
                        } else {
                            msg = "Couldn't load that image. Use a direct image link."
                        }
                    }
                }
            }
        }
        item {
            Btn("Reset to background gradient", BW) {
                wallpaperFile(ctx).delete()
                onSet(null)
                msg = "Wallpaper reset."
            }
        }
        if (msg.isNotEmpty()) item { Text(msg, color = Color(0xFF9BE7A1), fontSize = 20.sp) }
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun WeatherScreen(wx: Wx, onChange: (Wx) -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var city by remember { mutableStateOf(wx.city) }
    var msg by remember { mutableStateOf("") }
    Page {
        title("Weather")
        note("Type your city. Weather shows next to the clock on the home screen.")
        item { Field(city, "City, e.g. Mumbai") { city = it } }
        item {
            Btn("Save city & show weather", BW) {
                if (city.isNotBlank()) {
                    msg = "Looking up..."
                    scope.launch {
                        val g = withContext(Dispatchers.IO) { geocode(city.trim()) }
                        if (g != null) {
                            onChange(g.copy(f = wx.f))
                            msg = "Showing weather for ${g.city}"
                        } else {
                            msg = "City not found, or no internet."
                        }
                    }
                }
            }
        }
        item { SettingRow("Units", if (wx.f) "Fahrenheit" else "Celsius") { onChange(wx.copy(f = !wx.f)) } }
        item { Btn("Turn weather off", BW) { onChange(wx.copy(on = false)); msg = "Weather off." } }
        if (msg.isNotEmpty()) item { Text(msg, color = Color(0xFF9BE7A1), fontSize = 20.sp) }
        item { Btn("Back", BW, onBack) }
    }
}

private fun timerMsg(at: Long): String =
    if (at > System.currentTimeMillis()) "Sleep timer set for " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(at)) else ""

@Composable
fun SleepSettings(prefs: Prefs, pkgs: List<String>, onBlackNow: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf(timerMsg(prefs.sleepAt)) }
    Page {
        title("Sleep timer & RAM")
        note("When the timer ends, playback is paused and a black screen is shown. Apps can't power the Stick off.")
        items(listOf(15, 30, 60, 90)) { m ->
            SettingRow("Sleep in $m minutes") {
                prefs.sleepAt = setSleepTimer(ctx, m)
                msg = timerMsg(prefs.sleepAt)
            }
        }
        item { SettingRow("Cancel sleep timer") { cancelSleepTimer(ctx); prefs.sleepAt = 0L; msg = "Timer cancelled." } }
        item { SettingRow("Black screen now", "any key wakes", onClick = onBlackNow) }
        item {
            SettingRow("Clear RAM") {
                scope.launch {
                    val before = freeMb(ctx)
                    withContext(Dispatchers.IO) { killOthers(ctx, pkgs) }
                    delay(1200)
                    msg = "Free RAM: $before MB -> ${freeMb(ctx)} MB"
                }
            }
        }
        if (msg.isNotEmpty()) item { Text(msg, color = Color(0xFF9BE7A1), fontSize = 20.sp) }
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun SleepScreen(onWake: () -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    BackHandler { onWake() }
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(fr)
            .onKeyEvent { onWake(); true }
            .clickable { onWake() }
    )
}

@Composable
fun DefaultHomeScreen(onBack: () -> Unit) {
    Page {
        title("Make this my default home")
        note("Fire OS has no setting for this. It takes a one-time ADB command, run from a phone or PC on the same Wi-Fi.")
        note("1. Turn on ADB debugging: Settings > My Fire TV > Developer options.")
        note("2. Find the Stick's IP: Settings > My Fire TV > About > Network.")
        note("3. Run: adb connect <IP>:5555")
        note("4. Run: adb shell pm disable-user --user 0 com.amazon.tv.launcher")
        note("5. Press Home. This launcher should open.")
        note("To undo, run: adb shell pm enable com.amazon.tv.launcher")
        note("If Home does nothing or acts strange, run the undo command.")
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun DownloadScreen(status: String, onGo: (String) -> Unit, onBack: () -> Unit) {
    var url by remember { mutableStateOf("") }
    Page {
        title("Download & install an APK")
        note("Enter a direct link to an .apk file.")
        item { Field(url, "https://example.com/app.apk") { url = it } }
        item { Btn("Download & install", BW) { if (url.isNotBlank()) onGo(url) } }
        if (status.isNotEmpty()) item { Text(status, color = Color(0xFF9BE7A1), fontSize = 20.sp) }
        item { Btn("Back", BW, onBack) }
    }
}


// ---------- cinematic home + recommendations ----------

@Composable
fun HeroButton(text: String, onFocus: (Boolean) -> Unit, onPrev: () -> Unit, onNext: () -> Unit, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (f) 1.06f else 1f, tween(110), label = "hb")
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(if (f) Color.White else Color(0x40FFFFFF))
            .border(1.dp, if (f) Color.Transparent else Color(0x55FFFFFF), shape)
            .onFocusChanged { f = it.isFocused; onFocus(it.isFocused) }
            .onPreviewKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown && (e.key == Key.DirectionLeft || e.key == Key.DirectionRight)) {
                    if (e.key == Key.DirectionRight) onNext() else onPrev()
                    true
                } else false
            }
            .clickable(onClick = onClick)
            .padding(horizontal = 32.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Canvas(Modifier.size(14.dp)) {
            val p = Path().apply {
                moveTo(0f, 0f)
                lineTo(size.width, size.height / 2f)
                lineTo(0f, size.height)
                close()
            }
            drawPath(p, if (f) Color.Black else Color.White)
        }
        Text(text, color = if (f) Color.Black else Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun CinematicHome(
    heroes: List<Hero>, images: Map<String, Bitmap>, logos: Map<String, Bitmap>, idx: Int,
    onNext: () -> Unit, onPrev: () -> Unit, onPlay: (Hero) -> Unit,
    favs: List<AppItem>, tileSize: Int, modes: Map<String, Int>, online: Boolean, weather: String,
    onSettings: () -> Unit, onAll: () -> Unit, onOptions: (String) -> Unit
) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(10_000) } }
    val hm = remember(now) { SimpleDateFormat("h:mm", Locale.getDefault()).format(Date(now)) }
    val ap = remember(now) { SimpleDateFormat("a", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date(now)).uppercase() }
    val ctx = LocalContext.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(favs.size) { delay(150); runCatching { fr.requestFocus() } }
    var heroFocused by remember { mutableStateOf(false) }
    LaunchedEffect(heroes.size, heroFocused) {
        if (heroes.size > 1 && !heroFocused) {
            while (true) { delay(9000); onNext() }
        }
    }
    val hero = heroes.getOrNull(idx)
    val bmp = hero?.let { images[it.id] }
    val (w, h) = TILE_DIMS[minOf(tileSize, 1)]
    val dockH = h + 64
    val panel = RoundedCornerShape(32.dp)

    Box(Modifier.fillMaxSize()) {
        Crossfade(targetState = bmp, animationSpec = tween(700), label = "hero") { b ->
            if (b != null) {
                val img = remember(b) { b.asImageBitmap() }
                Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(listOf(Color(0xE6000000), Color(0x8C000000), Color(0x00000000)))
            )
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(320.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
        )
        Box(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().height(150.dp)
                .background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent)))
        )
        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().padding(start = 60.dp, end = 60.dp, top = 22.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(hm, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
                    Text(ap, color = Color(0xCCFFFFFF), fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp, bottom = 10.dp))
                }
                Text(
                    date + (if (weather.isNotEmpty()) "   |   $weather" else ""),
                    color = Color(0xD9FFFFFF), fontSize = 17.sp, letterSpacing = 1.5.sp
                )
            }
            Spacer(Modifier.weight(1f))
            StatusPill(online, onSettings)
        }
        if (hero != null) {
            Column(
                Modifier.align(Alignment.BottomStart)
                    .padding(start = 60.dp, bottom = (dockH + 58).dp).widthIn(max = 540.dp)
            ) {
                Crossfade(targetState = hero, animationSpec = tween(500), label = "heroText") { hv ->
                    if (hv != null) {
                        val lg = logos[hv.id]
                        val meta = listOf(
                            hv.year,
                            if (hv.type == "movie") "Movie" else "Series",
                            if (hv.rating.isNotEmpty()) "IMDb " + hv.rating else "",
                            hv.genres.take(2).joinToString(", ")
                        ).filter { it.isNotEmpty() }.joinToString("   \u00B7   ")
                        Column {
                            Text(hv.tag, color = Color(0xCCFFFFFF), fontSize = 12.sp, letterSpacing = 2.sp)
                            Box(Modifier.height(72.dp).padding(top = 6.dp), contentAlignment = Alignment.CenterStart) {
                                if (lg != null) {
                                    val li = remember(lg) { lg.asImageBitmap() }
                                    Image(
                                        li, hv.name, Modifier.height(64.dp).widthIn(max = 320.dp),
                                        contentScale = ContentScale.Fit, alignment = Alignment.CenterStart
                                    )
                                } else {
                                    Text(
                                        hv.name, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.SemiBold,
                                        maxLines = 2, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Text(meta, color = Color(0xD9FFFFFF), fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                            Text(
                                hv.overview, color = Color(0xB3FFFFFF), fontSize = 15.sp, maxLines = 2,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
                Row(
                    Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    HeroButton("Play", { heroFocused = it }, onPrev, onNext) { onPlay(hero) }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        for (i in heroes.indices) {
                            Box(
                                Modifier.size(if (i == idx) 9.dp else 6.dp).clip(CircleShape)
                                    .background(if (i == idx) Color.White else Color(0x66FFFFFF))
                            )
                        }
                    }
                }
            }
        }
        Box(
            Modifier.align(Alignment.BottomCenter).padding(start = 36.dp, end = 36.dp, bottom = 34.dp)
                .fillMaxWidth().clip(panel)
                .background(Color(0x2EFFFFFF))
                .border(1.dp, Brush.verticalGradient(listOf(Color(0x66FFFFFF), Color(0x14FFFFFF))), panel)
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                itemsIndexed(favs, key = { _, a -> a.pkg }) { i, a ->
                    Tile(
                        a, w, h, modes[a.pkg] ?: 0,
                        if (i == 0) Modifier.focusRequester(fr) else Modifier,
                        onMenu = { onOptions(a.pkg) }
                    ) { launchApp(ctx, a.pkg) }
                }
                item(key = "__all") {
                    TileFrame(w, h, "All apps", if (favs.isEmpty()) Modifier.focusRequester(fr) else Modifier, onAll) {
                        GridIcon(Color.White, h * 0.4f)
                    }
                }
            }
        }
    }
}

@Composable
fun HeroSettingsScreen(
    cinematic: Boolean, onCinematic: () -> Unit,
    targets: List<PlayTarget>, targetLabel: String, onTarget: () -> Unit,
    region: Int, onRegion: () -> Unit,
    types: Int, onTypes: () -> Unit,
    genres: Set<String>, onGenre: (String) -> Unit,
    taste: Map<String, Int>, onResetTaste: () -> Unit,
    traktOn: Boolean, onTrakt: () -> Unit,
    onRefresh: () -> Unit, status: String, onBack: () -> Unit
) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Page {
        title("Recommendations")
        note(
            if (traktOn) "Picks use your Trakt recommendations and Continue Watching, with Cinemeta artwork."
            else "Connect Trakt for personal picks and Indian titles. Until then, picks follow your favorite genres."
        )
        item { SettingRow("Home style", if (cinematic) "Cinematic" else "Classic", Modifier.focusRequester(fr), onCinematic) }
        item { SettingRow("Play with", if (targets.isEmpty()) "no app found" else targetLabel, onClick = onTarget) }
        item { SettingRow("Region focus", listOf("Indian first", "Mixed", "International")[region], onClick = onRegion) }
        item { SettingRow("Show", listOf("Movies & series", "Movies", "Series")[types], onClick = onTypes) }
        item { SettingRow("Trakt", if (traktOn) "Connected" else "Not connected", onClick = onTrakt) }
        header("FAVORITE GENRES")
        items(ALL_GENRES) { g -> SettingRow(g, if (g in genres) "On" else "Off") { onGenre(g) } }
        header("TASTE")
        item {
            SettingRow("Learned from what you play", if (taste.isEmpty()) "nothing yet" else topTaste(taste).joinToString(", ")) {
                onResetTaste()
            }
        }
        item { SettingRow("Refresh picks now", onClick = onRefresh) }
        if (status.isNotEmpty()) item { Text(status, color = Color(0xFF9BE7A1), fontSize = 18.sp) }
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun TraktScreen(
    id: String, secret: String, connected: Boolean,
    onId: (String) -> Unit, onSecret: (String) -> Unit,
    onTokens: (TraktTokens) -> Unit, onDisconnect: () -> Unit, onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Page {
        title("Trakt")
        note("Create a free app at trakt.tv/oauth/applications with Redirect URI urn:ietf:wg:oauth:2.0:oob, then enter its Client ID and Secret here.")
        item { Field(id, "Client ID") { onId(it) } }
        item { Field(secret, "Client Secret") { onSecret(it) } }
        item {
            SettingRow(if (connected) "Reconnect Trakt" else "Connect Trakt", if (connected) "connected" else "") {
                if (id.isBlank() || secret.isBlank()) {
                    msg = "Enter the Client ID and Client Secret first."
                } else {
                    scope.launch {
                        msg = "Contacting Trakt..."
                        val dc = try {
                            withContext(Dispatchers.IO) { traktDeviceCode(id.trim()) }
                        } catch (e: java.io.IOException) {
                            msg = "Couldn't reach Trakt. Check the Client ID and internet."
                            return@launch
                        }
                        code = dc.userCode
                        msg = "On your phone, open trakt.tv/activate and enter this code."
                        var waited = 0
                        while (waited < dc.expiresIn) {
                            delay(dc.interval * 1000L)
                            waited += dc.interval
                            val t = try {
                                withContext(Dispatchers.IO) { traktPollToken(id.trim(), secret.trim(), dc.deviceCode) }
                            } catch (e: java.io.IOException) {
                                msg = "Trakt refused the request. Check the Client Secret and try again."
                                code = ""
                                return@launch
                            }
                            if (t != null) {
                                onTokens(t)
                                code = ""
                                msg = "Trakt connected!"
                                return@launch
                            }
                        }
                        code = ""
                        msg = "The code expired. Try again."
                    }
                }
            }
        }
        if (code.isNotEmpty()) {
            item { Text(code, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp) }
        }
        if (connected) item { SettingRow("Disconnect Trakt") { onDisconnect(); msg = "Disconnected." } }
        if (msg.isNotEmpty()) item { Text(msg, color = Color(0xFF9BE7A1), fontSize = 18.sp) }
        item { Btn("Back", BW, onBack) }
    }
}
