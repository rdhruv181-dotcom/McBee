package com.myfire.launcher

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val THEMES = listOf(
    listOf(Color(0xFF0F1226), Color(0xFF3A1F6E)),
    listOf(Color(0xFF1A0A0A), Color(0xFF6B1414)),
    listOf(Color(0xFF04121F), Color(0xFF0B4A6F)),
    listOf(Color(0xFF07140C), Color(0xFF1B5E3A)),
    listOf(Color(0xFF000000), Color(0xFF161616))
)
val THEME_NAMES = listOf("Midnight", "Crimson", "Ocean", "Forest", "Black")
val SIZE_NAMES = listOf("Small", "Medium", "Large")
val TILE_DIMS = listOf(160 to 90, 210 to 118, 270 to 152)

enum class Screen { HOME, SETTINGS, APPS, DOWNLOAD }

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val status = mutableStateOf("")
    private var dlId = -1L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id != dlId) return
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                val ok = c.moveToFirst() &&
                    c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL
                if (ok) {
                    status.value = "Downloaded. Opening installer..."
                    installApk(this@MainActivity, apkFile(this@MainActivity))
                } else {
                    status.value = "Download failed. Check the link."
                }
            }
        }
    }

    private fun startDownload(raw: String) {
        val u = raw.trim().let { if (it.startsWith("http")) it else "https://$it" }
        try {
            dlId = enqueueDownload(this, u)
            status.value = "Downloading..."
        } catch (e: Exception) {
            status.value = "Failed: ${e.message}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED
        )
        val prefs = Prefs(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherApp(prefs, tick.intValue, status.value) { startDownload(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }
}

@Composable
fun LauncherApp(prefs: Prefs, refresh: Int, status: String, onDownload: (String) -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var hidden by remember { mutableStateOf(prefs.hidden) }
    var order by remember { mutableStateOf(prefs.order) }
    var tile by remember { mutableIntStateOf(prefs.tileSize) }
    var theme by remember { mutableIntStateOf(prefs.theme) }
    var all by remember { mutableStateOf<List<AppItem>>(emptyList()) }

    LaunchedEffect(refresh) { all = withContext(Dispatchers.IO) { loadApps(ctx) } }
    val sorted = remember(all, order) { sortApps(all, order) }
    val visible = remember(sorted, hidden) { sorted.filter { it.pkg !in hidden } }

    BackHandler { if (screen != Screen.HOME) screen = Screen.HOME }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(THEMES[theme]))) {
        when (screen) {
            Screen.HOME -> Home(visible, tile, isOnline(ctx)) { screen = Screen.SETTINGS }
            Screen.SETTINGS -> SettingsScreen(
                tile, theme,
                onTile = { tile = (tile + 1) % 3; prefs.tileSize = tile },
                onTheme = { theme = (theme + 1) % THEMES.size; prefs.theme = theme },
                onApps = { screen = Screen.APPS },
                onDownload = { screen = Screen.DOWNLOAD },
                onBack = { screen = Screen.HOME }
            )
            Screen.APPS -> AppsScreen(
                sorted, hidden,
                onToggle = { p ->
                    hidden = if (p in hidden) hidden - p else hidden + p
                    prefs.hidden = hidden
                },
                onMove = { from, to ->
                    if (to in sorted.indices) {
                        val l = sorted.map { it.pkg }.toMutableList()
                        val t = l[from]; l[from] = l[to]; l[to] = t
                        order = l; prefs.order = l
                    }
                },
                onBack = { screen = Screen.SETTINGS }
            )
            Screen.DOWNLOAD -> DownloadScreen(status, onDownload) { screen = Screen.SETTINGS }
        }
    }
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (f) Color.White else Color(0x33FFFFFF))
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text, color = if (f) Color.Black else Color.White, fontSize = 20.sp, maxLines = 1)
    }
}

@Composable
fun Home(apps: List<AppItem>, tileSize: Int, online: Boolean, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(10_000) } }
    val time = remember(now) { SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date(now)) }
    val fr = remember { FocusRequester() }
    LaunchedEffect(apps.size) {
        if (apps.isNotEmpty()) { delay(150); runCatching { fr.requestFocus() } }
    }
    val (w, h) = TILE_DIMS[tileSize]

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 32.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Row(
                Modifier.clip(RoundedCornerShape(32.dp)).background(Color(0x66000000)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(time, color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(start = 12.dp))
                Text(if (online) "Wi-Fi" else "Offline", color = Color(0xCCFFFFFF), fontSize = 18.sp)
                Btn("Settings", onClick = onSettings)
            }
        }
        Spacer(Modifier.weight(1f))
        Text(time, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Bold)
        Text(date, color = Color(0xCCFFFFFF), fontSize = 22.sp)
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color(0x55000000))) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                itemsIndexed(apps, key = { _, a -> a.pkg }) { i, a ->
                    Tile(a, w, h, if (i == 0) Modifier.focusRequester(fr) else Modifier) {
                        launchApp(ctx, a.pkg)
                    }
                }
            }
        }
    }
}

@Composable
fun Tile(item: AppItem, w: Int, h: Int, modifier: Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.12f else 1f, tween(120), label = "scale")
    val img = remember(item.pkg) { item.icon.asImageBitmap() }
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .size(w.dp, h.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(Color.Black)
            .border(if (focused) 3.dp else 0.dp, if (focused) Color.White else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (item.banner) {
            Image(img, item.label, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(img, item.label, Modifier.size((h * 0.5f).dp))
                Text(
                    item.label, color = Color.White, fontSize = 13.sp, maxLines = 1,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(
    tile: Int, theme: Int,
    onTile: () -> Unit, onTheme: () -> Unit, onApps: () -> Unit, onDownload: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Column(Modifier.fillMaxSize().padding(64.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Btn("Choose & reorder apps", Modifier.focusRequester(fr).width(520.dp), onApps)
        Btn("Tile size: ${SIZE_NAMES[tile]}", Modifier.width(520.dp), onTile)
        Btn("Theme: ${THEME_NAMES[theme]}", Modifier.width(520.dp), onTheme)
        Btn("Download & install an APK", Modifier.width(520.dp), onDownload)
        Btn("Fire TV system settings", Modifier.width(520.dp)) {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        Btn("Back", Modifier.width(520.dp), onBack)
    }
}

@Composable
fun AppsScreen(
    apps: List<AppItem>, hidden: Set<String>,
    onToggle: (String) -> Unit, onMove: (Int, Int) -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(48.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Apps (click to show/hide)", color = Color.White, fontSize = 30.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Btn("Done", onClick = onBack)
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(apps, key = { _, a -> a.pkg }) { idx, a ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn((if (a.pkg in hidden) "Hidden   " else "Shown    ") + a.label, Modifier.weight(1f)) {
                        onToggle(a.pkg)
                    }
                    Btn("Up") { onMove(idx, idx - 1) }
                    Btn("Down") { onMove(idx, idx + 1) }
                }
            }
        }
    }
}

@Composable
fun DownloadScreen(status: String, onGo: (String) -> Unit, onBack: () -> Unit) {
    var url by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(64.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Download & install an APK", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Enter a direct link to an .apk file.", color = Color(0xCCFFFFFF), fontSize = 18.sp)
        OutlinedTextField(
            value = url, onValueChange = { url = it }, singleLine = true,
            label = { Text("https://example.com/app.apk") },
            textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
            modifier = Modifier.fillMaxWidth()
        )
        Btn("Download & install") { if (url.isNotBlank()) onGo(url) }
        if (status.isNotEmpty()) Text(status, color = Color(0xFF9BE7A1), fontSize = 20.sp)
        Btn("Back", onClick = onBack)
    }
}
