package com.myfire.launcher

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val THEMES = listOf(
    listOf(Color(0xFF0F1226), Color(0xFF3A1F6E)),
    listOf(Color(0xFF1A0A0A), Color(0xFF6B1414)),
    listOf(Color(0xFF04121F), Color(0xFF0B4A6F)),
    listOf(Color(0xFF07140C), Color(0xFF1B5E3A)),
    listOf(Color(0xFF000000), Color(0xFF161616))
)
val THEME_NAMES = listOf("Midnight", "Crimson", "Ocean", "Forest", "Black")
val SIZE_NAMES = listOf("Small", "Medium", "Large")
val TILE_DIMS = listOf(160 to 90, 210 to 118, 270 to 152)
val ACCENTS = listOf(
    Color(0xFFFFFFFF), Color(0xFF8B6CFF), Color(0xFF00C2FF),
    Color(0xFFFFB300), Color(0xFFFF4081), Color(0xFF2ECC71)
)
val ACCENT_NAMES = listOf("White", "Purple", "Cyan", "Amber", "Pink", "Green")
val RING_NAMES = listOf("White", "Accent", "Gold", "Cyan", "Pink")
val SHAPE_NAMES = listOf("Square", "Rounded", "Extra round")
val SHAPE_DP = listOf(4, 16, 32)
val FONTS = listOf(FontFamily.Default, FontFamily.SansSerif, FontFamily.Serif, FontFamily.Monospace, FontFamily.Cursive)
val FONT_NAMES = listOf("Default", "Sans", "Serif", "Mono", "Cursive")
val LocalLook = compositionLocalOf { Look() }
val BW = Modifier.width(520.dp)

fun ringColor(l: Look): Color = when (l.ring) {
    0 -> Color.White
    1 -> ACCENTS[l.accent]
    2 -> Color(0xFFFFD54F)
    3 -> Color(0xFF00E5FF)
    else -> Color(0xFFFF4081)
}

enum class Screen { HOME, SETTINGS, APPS, LOOK, WALLPAPER, WEATHER, SLEEP, DEFAULT, DOWNLOAD }

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val status = mutableStateOf("")
    private val sleeping = mutableStateOf(false)
    private var dlId = -1L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id != dlId) return
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                val ok = c.moveToFirst() &&
                    c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL
                if (ok) {
                    status.value = "Downloaded. Opening installer..."
                    installApk(this@MainActivity, apkFile(this@MainActivity))
                } else {
                    status.value = "Download failed. Check the link."
                }
            }
        }
    }

    private fun startDownload(raw: String) {
        val u = raw.trim().let { if (it.startsWith("http")) it else "https://$it" }
        try {
            dlId = enqueueDownload(this, u)
            status.value = "Downloading..."
        } catch (e: Exception) {
            status.value = "Failed: ${e.message}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED
        )
        if (intent?.getBooleanExtra("sleep", false) == true) sleeping.value = true
        val prefs = Prefs(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherApp(prefs, tick.intValue, status.value, sleeping.value, { sleeping.value = it }) {
                    startDownload(it)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("sleep", false)) sleeping.value = true
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }
}

@Composable
fun LauncherApp(
    prefs: Prefs, refresh: Int, status: String,
    sleeping: Boolean, setSleeping: (Boolean) -> Unit, onDownload: (String) -> Unit
) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var hidden by remember { mutableStateOf(prefs.hidden) }
    var favs by remember { mutableStateOf(prefs.favs) }
    var order by remember { mutableStateOf(prefs.order) }
    var tile by remember { mutableIntStateOf(prefs.tileSize) }
    var theme by remember { mutableIntStateOf(prefs.theme) }
    var look by remember { mutableStateOf(prefs.look) }
    var wx by remember { mutableStateOf(prefs.wx) }
    var weather by remember { mutableStateOf("") }
    var all by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var wallpaper by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(refresh) { all = withContext(Dispatchers.IO) { loadApps(ctx) } }
    LaunchedEffect(Unit) { wallpaper = withContext(Dispatchers.IO) { loadWallpaper(ctx) } }
    LaunchedEffect(wx, refresh) {
        weather = if (wx.on && wx.city.isNotBlank()) {
            (withContext(Dispatchers.IO) { fetchWeather(wx) }) ?: weather
        } else ""
    }
    val sorted = remember(all, order) { sortApps(all, order) }
    val visible = remember(sorted, hidden) { sorted.filter { it.pkg !in hidden } }
    val favList = remember(visible, favs) { visible.filter { it.pkg in favs } }
    val restList = remember(visible, favs) { visible.filter { it.pkg !in favs } }
    val bg = remember(wallpaper, look.blur) { wallpaper?.let { blurBitmap(it, look.blur) } }

    BackHandler {
        screen = if (screen == Screen.SETTINGS || screen == Screen.HOME) Screen.HOME else Screen.SETTINGS
    }

    CompositionLocalProvider(LocalLook provides look) {
        ProvideTextStyle(TextStyle(fontFamily = FONTS[look.font])) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(THEMES[theme]))) {
                bg?.let { b ->
                    val img = remember(b) { b.asImageBitmap() }
                    Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = look.dark / 10f)))
                }
                when (screen) {
                    Screen.HOME -> Home(favList, restList, tile, isOnline(ctx), weather) { screen = Screen.SETTINGS }
                    Screen.SETTINGS -> SettingsScreen(
                        tile, theme,
                        go = { screen = it },
                        onTile = { tile = (tile + 1) % 3; prefs.tileSize = tile },
                        onTheme = { theme = (theme + 1) % THEMES.size; prefs.theme = theme },
                        onBack = { screen = Screen.HOME }
                    )
                    Screen.APPS -> AppsScreen(
                        sorted, hidden, favs,
                        onToggle = { p ->
                            hidden = if (p in hidden) hidden - p else hidden + p
                            prefs.hidden = hidden
                        },
                        onFav = { p ->
                            favs = if (p in favs) favs - p else favs + p
                            prefs.favs = favs
                        },
                        onMove = { from, to ->
                            if (to in sorted.indices) {
                                val l = sorted.map { it.pkg }.toMutableList()
                                val t = l[from]; l[from] = l[to]; l[to] = t
                                order = l; prefs.order = l
                            }
                        },
                        onBack = { screen = Screen.SETTINGS }
                    )
                    Screen.LOOK -> LookScreen(look, { look = it; prefs.look = it }) { screen = Screen.SETTINGS }
                    Screen.WALLPAPER -> WallpaperScreen({ wallpaper = it }) { screen = Screen.SETTINGS }
                    Screen.WEATHER -> WeatherScreen(wx, { wx = it; prefs.wx = it }) { screen = Screen.SETTINGS }
                    Screen.SLEEP -> SleepSettings(prefs, all.map { it.pkg }, { setSleeping(true) }) { screen = Screen.SETTINGS }
                    Screen.DEFAULT -> DefaultHomeScreen { screen = Screen.SETTINGS }
                    Screen.DOWNLOAD -> DownloadScreen(status, onDownload) { screen = Screen.SETTINGS }
                }
                if (sleeping) SleepScreen { setSleeping(false) }
            }
        }
    }
}

// ---------- shared pieces ----------

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val accent = ACCENTS[LocalLook.current.accent]
    val fg = if (accent.luminance() > 0.35f) Color.Black else Color.White
    var f by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (f) accent else Color(0x33FFFFFF))
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(text, color = if (f) fg else Color.White, fontSize = 20.sp, maxLines = 1)
    }
}

@Composable
fun Page(content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 64.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

fun LazyListScope.title(t: String) {
    item { Text(t, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold) }
}

fun LazyListScope.note(t: String) {
    item { Text(t, color = Color(0xCCFFFFFF), fontSize = 18.sp) }
}

@Composable
fun Field(value: String, hint: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        label = { Text(hint) },
        textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun Stepper(label: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(BW, horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f))
        Btn("-", onClick = onMinus)
        Btn("+", onClick = onPlus)
    }
}

// ---------- home ----------

@Composable
fun Home(
    favs: List<AppItem>, rest: List<AppItem>, tileSize: Int,
    online: Boolean, weather: String, onSettings: () -> Unit
) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(10_000) } }
    val time = remember(now) { SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date(now)) }
    val fr = remember { FocusRequester() }
    val firstPkg = (favs.firstOrNull() ?: rest.firstOrNull())?.pkg
    LaunchedEffect(firstPkg) {
        if (firstPkg != null) { delay(150); runCatching { fr.requestFocus() } }
    }
    val hasFav = favs.isNotEmpty()

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 24.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Row(
                Modifier.clip(RoundedCornerShape(32.dp)).background(Color(0x66000000)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(time, color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(start = 12.dp))
                Text(if (online) "Wi-Fi" else "Offline", color = Color(0xCCFFFFFF), fontSize = 18.sp)
                Btn("Settings", onClick = onSettings)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Text(time, color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
            Column(Modifier.padding(bottom = 6.dp)) {
                Text(date, color = Color(0xCCFFFFFF), fontSize = 20.sp)
                if (weather.isNotEmpty()) Text(weather, color = Color(0xCCFFFFFF), fontSize = 18.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        if (hasFav) {
            RowLabel("Favorites")
            AppRow(favs, TILE_DIMS[tileSize], fr)
            if (rest.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                RowLabel("All apps")
                AppRow(rest, TILE_DIMS[0], null)
            }
        } else {
            AppRow(rest, TILE_DIMS[tileSize], fr)
        }
    }
}

@Composable
fun RowLabel(t: String) {
    Text(t, color = Color(0xCCFFFFFF), fontSize = 16.sp, modifier = Modifier.padding(start = 8.dp, bottom = 4.dp))
}

@Composable
fun AppRow(apps: List<AppItem>, dims: Pair<Int, Int>, fr: FocusRequester?) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0x55000000))) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            itemsIndexed(apps, key = { _, a -> a.pkg }) { i, a ->
                Tile(a, dims.first, dims.second, if (i == 0 && fr != null) Modifier.focusRequester(fr) else Modifier) {
                    launchApp(ctx, a.pkg)
                }
            }
        }
    }
}

@Composable
fun Tile(item: AppItem, w: Int, h: Int, modifier: Modifier, onClick: () -> Unit) {
    val look = LocalLook.current
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.12f else 1f, tween(120), label = "scale")
    val img = remember(item.pkg) { item.icon.asImageBitmap() }
    val shape = RoundedCornerShape(SHAPE_DP[look.shape].dp)
    Box(
        modifier
            .size(w.dp, h.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(Color.Black)
            .border(if (focused) 4.dp else 0.dp, if (focused) ringColor(look) else Color.Transparent, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (item.banner) {
            Image(img, item.label, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(img, item.label, Modifier.size((h * 0.5f).dp))
                Text(
                    item.label, color = Color.White, fontSize = 13.sp, maxLines = 1,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }
    }
}

// ---------- settings screens ----------

@Composable
fun SettingsScreen(
    tile: Int, theme: Int, go: (Screen) -> Unit,
    onTile: () -> Unit, onTheme: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Page {
        title("Settings")
        item { Btn("Apps: show, hide, reorder, favorite", Modifier.focusRequester(fr).width(520.dp)) { go(Screen.APPS) } }
        item { Btn("Look & feel", BW) { go(Screen.LOOK) } }
        item { Btn("Wallpaper", BW) { go(Screen.WALLPAPER) } }
        item { Btn("Weather", BW) { go(Screen.WEATHER) } }
        item { Btn("Sleep timer & clear RAM", BW) { go(Screen.SLEEP) } }
        item { Btn("Tile size: ${SIZE_NAMES[tile]}", BW, onTile) }
        item { Btn("Background: ${THEME_NAMES[theme]}", BW, onTheme) }
        item { Btn("Make this my default home", BW) { go(Screen.DEFAULT) } }
        item { Btn("Download & install an APK", BW) { go(Screen.DOWNLOAD) } }
        item {
            Btn("Fire TV system settings", BW) {
                ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun AppsScreen(
    apps: List<AppItem>, hidden: Set<String>, favs: Set<String>,
    onToggle: (String) -> Unit, onFav: (String) -> Unit, onMove: (Int, Int) -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(48.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Apps (click name to show/hide)", color = Color.White, fontSize = 28.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Btn("Done", onClick = onBack)
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(apps, key = { _, a -> a.pkg }) { idx, a ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn((if (a.pkg in hidden) "Hidden   " else "Shown    ") + a.label, Modifier.weight(1f)) {
                        onToggle(a.pkg)
                    }
                    Btn(if (a.pkg in favs) "Unfav" else "Fav") { onFav(a.pkg) }
                    Btn("Up") { onMove(idx, idx - 1) }
                    Btn("Down") { onMove(idx, idx + 1) }
                }
            }
        }
    }
}

@Composable
fun LookScreen(look: Look, onChange: (Look) -> Unit, onBack: () -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Page {
        title("Look & feel")
        item {
            Btn("Accent color: ${ACCENT_NAMES[look.accent]}", Modifier.focusRequester(fr).width(520.dp)) {
                onChange(look.copy(accent = (look.accent + 1) % ACCENTS.size))
            }
        }
        item {
            Btn("Focus ring: ${RING_NAMES[look.ring]}", BW) {
                onChange(look.copy(ring = (look.ring + 1) % RING_NAMES.size))
            }
        }
        item {
            Btn("Tile shape: ${SHAPE_NAMES[look.shape]}", BW) {
                onChange(look.copy(shape = (look.shape + 1) % SHAPE_NAMES.size))
            }
        }
        item {
            Btn("Font: ${FONT_NAMES[look.font]}", BW) {
                onChange(look.copy(font = (look.font + 1) % FONTS.size))
            }
        }
        item {
            Stepper("Wallpaper darkness: ${look.dark * 10}%",
                { onChange(look.copy(dark = (look.dark - 1).coerceAtLeast(0))) },
                { onChange(look.copy(dark = (look.dark + 1).coerceAtMost(10))) })
        }
        item {
            Stepper("Wallpaper blur: ${look.blur}",
                { onChange(look.copy(blur = (look.blur - 1).coerceAtLeast(0))) },
                { onChange(look.copy(blur = (look.blur + 1).coerceAtMost(BLUR_F.size - 1))) })
        }
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun WallpaperScreen(onSet: (Bitmap?) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Page {
        title("Wallpaper")
        note("Enter a direct link to an image (.jpg or .png).")
        item { Field(url, "https://example.com/wallpaper.jpg") { url = it } }
        item {
            Btn("Set wallpaper", BW) {
                if (url.isNotBlank()) {
                    msg = "Downloading..."
                    val u = url.trim().let { if (it.startsWith("http")) it else "https://$it" }
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { downloadWallpaper(ctx, u) }
                        if (ok) {
                            onSet(withContext(Dispatchers.IO) { loadWallpaper(ctx) })
                            msg = "Wallpaper set!"
                        } else {
                            msg = "Couldn't load that image. Use a direct image link."
                        }
                    }
                }
            }
        }
        item {
            Btn("Reset to background gradient", BW) {
                wallpaperFile(ctx).delete()
                onSet(null)
                msg = "Wallpaper reset."
            }
        }
        if (msg.isNotEmpty()) item { Text(msg, color = Color(0xFF9BE7A1), fontSize = 20.sp) }
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun WeatherScreen(wx: Wx, onChange: (Wx) -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var city by remember { mutableStateOf(wx.city) }
    var msg by remember { mutableStateOf("") }
    Page {
        title("Weather")
        note("Type your city. Weather shows next to the clock on the home screen.")
        item { Field(city, "City, e.g. Mumbai") { city = it } }
        item {
            Btn("Save city & show weather", BW) {
                if (city.isNotBlank()) {
                    msg = "Looking up..."
                    scope.launch {
                        val g = withContext(Dispatchers.IO) { geocode(city.trim()) }
                        if (g != null) {
                            onChange(g.copy(f = wx.f))
                            msg = "Showing weather for ${g.city}"
                        } else {
                            msg = "City not found, or no internet."
                        }
                    }
                }
            }
        }
        item {
            Btn("Units: " + (if (wx.f) "Fahrenheit" else "Celsius"), BW) { onChange(wx.copy(f = !wx.f)) }
        }
        item { Btn("Turn weather off", BW) { onChange(wx.copy(on = false)); msg = "Weather off." } }
        if (msg.isNotEmpty()) item { Text(msg, color = Color(0xFF9BE7A1), fontSize = 20.sp) }
        item { Btn("Back", BW, onBack) }
    }
}

private fun timerMsg(at: Long): String =
    if (at > System.currentTimeMillis()) "Sleep timer set for " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(at)) else ""

@Composable
fun SleepSettings(prefs: Prefs, pkgs: List<String>, onBlackNow: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf(timerMsg(prefs.sleepAt)) }
    Page {
        title("Sleep timer & RAM")
        note("When the timer ends, playback is paused and a black screen is shown. Apps can't power the Stick off.")
        items(listOf(15, 30, 60, 90)) { m ->
            Btn("Sleep in $m minutes", BW) {
                prefs.sleepAt = setSleepTimer(ctx, m)
                msg = timerMsg(prefs.sleepAt)
            }
        }
        item { Btn("Cancel sleep timer", BW) { cancelSleepTimer(ctx); prefs.sleepAt = 0L; msg = "Timer cancelled." } }
        item { Btn("Black screen now (press any key to wake)", BW, onBlackNow) }
        item {
            Btn("Clear RAM", BW) {
                scope.launch {
                    val before = freeMb(ctx)
                    withContext(Dispatchers.IO) { killOthers(ctx, pkgs) }
                    delay(1200)
                    msg = "Free RAM: $before MB -> ${freeMb(ctx)} MB"
                }
            }
        }
        if (msg.isNotEmpty()) item { Text(msg, color = Color(0xFF9BE7A1), fontSize = 20.sp) }
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun SleepScreen(onWake: () -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    BackHandler { onWake() }
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(fr)
            .onKeyEvent { onWake(); true }
            .clickable { onWake() }
    )
}

@Composable
fun DefaultHomeScreen(onBack: () -> Unit) {
    Page {
        title("Make this my default home")
        note("Fire OS has no setting for this. It takes a one-time ADB command, run from a phone or PC on the same Wi-Fi.")
        note("1. Turn on ADB debugging: Settings > My Fire TV > Developer options.")
        note("2. Find the Stick's IP: Settings > My Fire TV > About > Network.")
        note("3. Run: adb connect <IP>:5555")
        note("4. Run: adb shell pm disable-user --user 0 com.amazon.tv.launcher")
        note("5. Press Home. This launcher should open.")
        note("To undo, run: adb shell pm enable com.amazon.tv.launcher")
        note("If Home does nothing or acts strange, run the undo command.")
        item { Btn("Back", BW, onBack) }
    }
}

@Composable
fun DownloadScreen(status: String, onGo: (String) -> Unit, onBack: () -> Unit) {
    var url by remember { mutableStateOf("") }
    Page {
        title("Download & install an APK")
        note("Enter a direct link to an .apk file.")
        item { Field(url, "https://example.com/app.apk") { url = it } }
        item { Btn("Download & install", BW) { if (url.isNotBlank()) onGo(url) } }
        if (status.isNotEmpty()) item { Text(status, color = Color(0xFF9BE7A1), fontSize = 20.sp) }
        item { Btn("Back", BW, onBack) }
    }
}
