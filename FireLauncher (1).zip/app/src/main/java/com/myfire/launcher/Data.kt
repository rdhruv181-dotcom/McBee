package com.myfire.launcher

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class AppItem(val pkg: String, val label: String, val icon: Bitmap, val banner: Boolean)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden", v.toSet()).apply() }
    var order: List<String>
        get() = (sp.getString("order", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("order", v.joinToString(",")).apply() }
    var tileSize: Int
        get() = sp.getInt("tile", 1)
        set(v) { sp.edit().putInt("tile", v).apply() }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
}

private fun Drawable.toSmallBitmap(): Bitmap {
    val iw = if (intrinsicWidth > 0) intrinsicWidth else 192
    val ih = if (intrinsicHeight > 0) intrinsicHeight else 192
    val s = minOf(1f, 320f / maxOf(iw, ih))
    return toBitmap(maxOf(1, (iw * s).toInt()), maxOf(1, (ih * s).toInt()))
}

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val seen = HashSet<String>()
    val out = ArrayList<AppItem>()
    for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            try {
                val banner = ri.activityInfo.loadBanner(pm)
                val d: Drawable = banner ?: ri.loadIcon(pm)
                out.add(AppItem(pkg, ri.loadLabel(pm).toString(), d.toSmallBitmap(), banner != null))
            } catch (e: Exception) { }
        }
    }
    return out
}

fun sortApps(all: List<AppItem>, order: List<String>): List<AppItem> {
    val idx = order.withIndex().associate { it.value to it.index }
    return all.sortedWith(compareBy<AppItem>({ idx[it.pkg] ?: Int.MAX_VALUE }, { it.label.lowercase() }))
}

fun launchApp(ctx: Context, pkg: String) {
    val pm = ctx.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
    if (i != null) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

fun apkFile(ctx: Context): File =
    File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "update.apk")

fun enqueueDownload(ctx: Context, url: String): Long {
    val f = apkFile(ctx)
    if (f.exists()) f.delete()
    val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val req = DownloadManager.Request(Uri.parse(url))
        .setTitle("Downloading app")
        .setMimeType("application/vnd.android.package-archive")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
        .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_DOWNLOADS, "update.apk")
    return dm.enqueue(req)
}

fun installApk(ctx: Context, file: File) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
    val i = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, "application/vnd.android.package-archive")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(i)
}

fun wallpaperFile(ctx: Context): File = File(ctx.filesDir, "wallpaper.jpg")

fun downloadWallpaper(ctx: Context, url: String): Boolean {
    return try {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        val bytes = conn.inputStream.use { it.readBytes() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1920) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false
        val out = if (bmp.width > 1280) Bitmap.createScaledBitmap(bmp, 1280, bmp.height * 1280 / bmp.width, true) else bmp
        wallpaperFile(ctx).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Exception) {
        false
    }
}

fun loadWallpaper(ctx: Context): Bitmap? {
    val f = wallpaperFile(ctx)
    return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
}
